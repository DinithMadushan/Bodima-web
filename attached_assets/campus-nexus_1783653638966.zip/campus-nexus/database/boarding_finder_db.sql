-- ============================================================
--  BOARDING FINDER SYSTEM — Full Database Schema
--  Database : boarding_finder
--  Engine   : MySQL 8.x  (InnoDB, UTF-8)
-- ============================================================

CREATE DATABASE IF NOT EXISTS boarding_finder
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE boarding_finder;

-- ============================================================
-- 1. ROLES  (lookup table)
-- ============================================================
CREATE TABLE roles (
    role_id   TINYINT      UNSIGNED NOT NULL AUTO_INCREMENT,
    role_name VARCHAR(20)  NOT NULL,           -- 'student' | 'owner' | 'admin'
    PRIMARY KEY (role_id),
    UNIQUE KEY uq_role_name (role_name)
) ENGINE=InnoDB;

INSERT INTO roles (role_name) VALUES ('student'), ('owner'), ('admin');

-- ============================================================
-- 2. USERS  (shared account table for all three roles)
-- ============================================================
CREATE TABLE users (
    user_id        INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    role_id        TINYINT      UNSIGNED NOT NULL,
    full_name      VARCHAR(100) NOT NULL,
    email          VARCHAR(150) NOT NULL,
    phone          VARCHAR(20)           DEFAULT NULL,
    password_hash  VARCHAR(255) NOT NULL,
    profile_photo  VARCHAR(255)          DEFAULT NULL,   -- file path / URL
    is_active      TINYINT(1)   NOT NULL DEFAULT 1,      -- 1=active, 0=banned
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_email (email),
    CONSTRAINT fk_users_role
        FOREIGN KEY (role_id) REFERENCES roles (role_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ============================================================
-- 3. STUDENTS  (extra profile fields for students)
-- ============================================================
CREATE TABLE students (
    student_id      INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT          UNSIGNED NOT NULL,
    student_reg_no  VARCHAR(50)           DEFAULT NULL,  -- campus registration
    faculty         VARCHAR(100)          DEFAULT NULL,
    year_of_study   TINYINT      UNSIGNED DEFAULT NULL,
    PRIMARY KEY (student_id),
    UNIQUE KEY uq_student_user (user_id),
    CONSTRAINT fk_students_user
        FOREIGN KEY (user_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 4. BOARDING OWNERS  (extra profile for owners)
-- ============================================================
CREATE TABLE boarding_owners (
    owner_id    INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT          UNSIGNED NOT NULL,
    nic_number  VARCHAR(20)           DEFAULT NULL,   -- national ID for verification
    is_verified TINYINT(1)   NOT NULL DEFAULT 0,      -- admin verifies owner
    PRIMARY KEY (owner_id),
    UNIQUE KEY uq_owner_user (user_id),
    CONSTRAINT fk_owners_user
        FOREIGN KEY (user_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 5. FACILITIES  (lookup — wifi, AC, hot water …)
-- ============================================================
CREATE TABLE facilities (
    facility_id   SMALLINT     UNSIGNED NOT NULL AUTO_INCREMENT,
    facility_name VARCHAR(80)  NOT NULL,
    PRIMARY KEY (facility_id),
    UNIQUE KEY uq_facility_name (facility_name)
) ENGINE=InnoDB;

INSERT INTO facilities (facility_name) VALUES
    ('WiFi'), ('Air Conditioning'), ('Hot Water'), ('Attached Bathroom'),
    ('Study Room'), ('Parking'), ('CCTV'), ('Generator Backup'),
    ('Laundry'), ('Kitchen Access'), ('Furnished Room');

-- ============================================================
-- 6. BOARDING HOUSES
-- ============================================================
CREATE TABLE boarding_houses (
    boarding_id      INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_id         INT          UNSIGNED NOT NULL,   -- FK → boarding_owners
    title            VARCHAR(150) NOT NULL,
    description      TEXT                  DEFAULT NULL,
    address          VARCHAR(255) NOT NULL,
    city             VARCHAR(100) NOT NULL,
    distance_km      DECIMAL(5,2)          DEFAULT NULL,  -- distance from campus
    monthly_rent     DECIMAL(10,2) NOT NULL,
    gender_allowed   ENUM('male','female','any') NOT NULL DEFAULT 'any',
    total_rooms      TINYINT      UNSIGNED DEFAULT NULL,
    available_rooms  TINYINT      UNSIGNED DEFAULT NULL,
    status           ENUM('pending','approved','rejected','inactive')
                     NOT NULL DEFAULT 'pending',
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                     ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (boarding_id),
    CONSTRAINT fk_boarding_owner
        FOREIGN KEY (owner_id) REFERENCES boarding_owners (owner_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 7. BOARDING PHOTOS
-- ============================================================
CREATE TABLE boarding_photos (
    photo_id    INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    boarding_id INT          UNSIGNED NOT NULL,
    photo_url   VARCHAR(255) NOT NULL,
    is_cover    TINYINT(1)   NOT NULL DEFAULT 0,   -- 1 = main/cover photo
    uploaded_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (photo_id),
    CONSTRAINT fk_photos_boarding
        FOREIGN KEY (boarding_id) REFERENCES boarding_houses (boarding_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 8. BOARDING ↔ FACILITIES  (many-to-many)
-- ============================================================
CREATE TABLE boarding_facilities (
    boarding_id INT          UNSIGNED NOT NULL,
    facility_id SMALLINT     UNSIGNED NOT NULL,
    PRIMARY KEY (boarding_id, facility_id),
    CONSTRAINT fk_bf_boarding
        FOREIGN KEY (boarding_id) REFERENCES boarding_houses (boarding_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_bf_facility
        FOREIGN KEY (facility_id) REFERENCES facilities (facility_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 9. MESSAGES  (student ↔ owner secure contact)
-- ============================================================
CREATE TABLE messages (
    message_id   INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    boarding_id  INT          UNSIGNED NOT NULL,
    sender_id    INT          UNSIGNED NOT NULL,   -- FK → users
    receiver_id  INT          UNSIGNED NOT NULL,   -- FK → users
    message_text TEXT         NOT NULL,
    is_read      TINYINT(1)   NOT NULL DEFAULT 0,
    sent_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (message_id),
    CONSTRAINT fk_msg_boarding
        FOREIGN KEY (boarding_id) REFERENCES boarding_houses (boarding_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_msg_sender
        FOREIGN KEY (sender_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_msg_receiver
        FOREIGN KEY (receiver_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 10. REVIEWS / RATINGS  (students review boardings)
-- ============================================================
CREATE TABLE reviews (
    review_id   INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    boarding_id INT          UNSIGNED NOT NULL,
    student_id  INT          UNSIGNED NOT NULL,   -- FK → students
    rating      TINYINT      UNSIGNED NOT NULL,   -- 1–5
    comment     TEXT                  DEFAULT NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (review_id),
    UNIQUE KEY uq_one_review (boarding_id, student_id),  -- one review per student per boarding
    CONSTRAINT fk_review_boarding
        FOREIGN KEY (boarding_id) REFERENCES boarding_houses (boarding_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_review_student
        FOREIGN KEY (student_id) REFERENCES students (student_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- ============================================================
-- 11. BOOKMARKS  (students save favourite boardings)
-- ============================================================
CREATE TABLE bookmarks (
    bookmark_id INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    student_id  INT          UNSIGNED NOT NULL,
    boarding_id INT          UNSIGNED NOT NULL,
    saved_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (bookmark_id),
    UNIQUE KEY uq_bookmark (student_id, boarding_id),
    CONSTRAINT fk_bm_student
        FOREIGN KEY (student_id) REFERENCES students (student_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_bm_boarding
        FOREIGN KEY (boarding_id) REFERENCES boarding_houses (boarding_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 12. ADMIN ACTIONS LOG  (audit trail)
-- ============================================================
CREATE TABLE admin_actions (
    action_id    INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    admin_id     INT          UNSIGNED NOT NULL,   -- FK → users (admin role)
    action_type  VARCHAR(50)  NOT NULL,            -- 'approve','reject','remove_user', …
    target_table VARCHAR(50)  NOT NULL,            -- table name affected
    target_id    INT          UNSIGNED NOT NULL,   -- PK of the affected row
    notes        TEXT                  DEFAULT NULL,
    acted_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (action_id),
    CONSTRAINT fk_action_admin
        FOREIGN KEY (admin_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ============================================================
-- 13. PASSWORD RESET TOKENS
-- ============================================================
CREATE TABLE password_resets (
    reset_id    INT          UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     INT          UNSIGNED NOT NULL,
    token       VARCHAR(255) NOT NULL,
    expires_at  DATETIME     NOT NULL,
    used        TINYINT(1)   NOT NULL DEFAULT 0,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (reset_id),
    CONSTRAINT fk_reset_user
        FOREIGN KEY (user_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- SAMPLE DATA  (enough to verify FK integrity)
-- ============================================================

-- Admin user
INSERT INTO users (role_id, full_name, email, phone, password_hash) VALUES
(3, 'System Admin', 'admin@boardingfinder.lk', '0771234567',
 '$2y$10$examplehashadmin');

-- Boarding owner
INSERT INTO users (role_id, full_name, email, phone, password_hash) VALUES
(2, 'Kamal Perera', 'kamal@example.lk', '0712345678',
 '$2y$10$examplehashowner');

INSERT INTO boarding_owners (user_id, nic_number, is_verified) VALUES (2, '198812345678', 1);

-- Student
INSERT INTO users (role_id, full_name, email, phone, password_hash) VALUES
(1, 'Nimal Silva', 'nimal@student.lk', '0761234567',
 '$2y$10$examplehashstudent');

INSERT INTO students (user_id, student_reg_no, faculty, year_of_study) VALUES
(3, 'S/2023/001', 'Faculty of Computing', 1);

-- Boarding house (pending admin approval)
INSERT INTO boarding_houses
    (owner_id, title, description, address, city, distance_km,
     monthly_rent, gender_allowed, total_rooms, available_rooms, status)
VALUES
(1, 'Sunrise Boarding', 'Clean and quiet rooms near campus.',
 '12/A, Kandy Road, Peradeniya', 'Kandy', 0.80,
 8500.00, 'any', 6, 3, 'approved');

-- Facilities for the boarding
INSERT INTO boarding_facilities (boarding_id, facility_id) VALUES (1,1),(1,3),(1,4),(1,7);

-- Photo
INSERT INTO boarding_photos (boarding_id, photo_url, is_cover) VALUES
(1, 'uploads/boardings/1/cover.jpg', 1);

-- Message from student to owner
INSERT INTO messages (boarding_id, sender_id, receiver_id, message_text) VALUES
(1, 3, 2, 'Hello, is the room still available for next month?');

-- Review
INSERT INTO reviews (boarding_id, student_id, rating, comment) VALUES
(1, 1, 4, 'Good location and clean facilities. Recommended.');

-- Bookmark
INSERT INTO bookmarks (student_id, boarding_id) VALUES (1, 1);

-- Admin action log
INSERT INTO admin_actions (admin_id, action_type, target_table, target_id, notes) VALUES
(1, 'approve', 'boarding_houses', 1, 'Verified and approved by admin.');

-- ============================================================
-- END OF SCHEMA
-- ============================================================
