-- ============================================================
-- FINAL DB INTEGRITY CHECK — boarding_finder
-- Created by: Dilmi100
-- Task: Final DB integrity check before go-live
-- ============================================================

USE boarding_finder;

-- Check all tables have data
SELECT 'users' AS table_name, COUNT(*) AS total_rows FROM users
UNION ALL
SELECT 'bookings', COUNT(*) FROM bookings
UNION ALL
SELECT 'payments', COUNT(*) FROM payments
UNION ALL
SELECT 'messages', COUNT(*) FROM messages
UNION ALL
SELECT 'reviews', COUNT(*) FROM reviews
UNION ALL
SELECT 'boarding_houses', COUNT(*) FROM boarding_houses
UNION ALL
SELECT 'facilities', COUNT(*) FROM facilities;

-- Check foreign keys
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    REFERENCED_TABLE_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE 
    TABLE_SCHEMA = 'boarding_finder'
    AND REFERENCED_TABLE_NAME IS NOT NULL
ORDER BY TABLE_NAME;