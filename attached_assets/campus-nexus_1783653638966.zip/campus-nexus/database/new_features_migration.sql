-- ============================================================
--  Campus Nexus — New Tables Migration
--  Run AFTER the existing boarding_finder_db.sql migration
--  File: database/new_features_migration.sql
-- ============================================================

USE boarding_finder_db;

-- ── Payments table ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `payments` (
  `id`                        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id`                INT NOT NULL,
  `payer_id`                  INT NOT NULL,
  `amount`                    DECIMAL(12,2) NOT NULL,
  `currency`                  VARCHAR(3) NOT NULL DEFAULT 'LKR',
  `payment_method`            ENUM('stripe','paypal') NOT NULL,
  `payment_type`              ENUM('deposit','first_rent','monthly') NOT NULL DEFAULT 'deposit',
  `status`                    ENUM('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
  `stripe_payment_intent_id`  VARCHAR(200) NULL,
  `stripe_client_secret`      VARCHAR(500) NULL,
  `paypal_order_id`           VARCHAR(200) NULL,
  `paypal_capture_id`         VARCHAR(200) NULL,
  `transaction_ref`           VARCHAR(200) NULL,
  `paid_at`                   DATETIME NULL,
  `created_at`                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_payment_booking`   (`booking_id`),
  KEY `idx_payment_payer`     (`payer_id`),
  KEY `idx_payment_status`    (`status`),
  KEY `idx_stripe_pi`         (`stripe_payment_intent_id`),
  KEY `idx_paypal_order`      (`paypal_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Conversations table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS `conversations` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `listing_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `owner_id`   INT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_conv` (`listing_id`, `student_id`, `owner_id`),
  KEY `idx_conv_student` (`student_id`),
  KEY `idx_conv_owner`   (`owner_id`),
  KEY `idx_conv_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Messages table ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `messages` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `conversation_id` INT UNSIGNED NOT NULL,
  `sender_id`       INT NOT NULL,
  `body`            TEXT NOT NULL,
  `is_read`         TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_msg_conv`   (`conversation_id`),
  KEY `idx_msg_sender` (`sender_id`),
  KEY `idx_msg_read`   (`is_read`),
  CONSTRAINT `fk_msg_conversation`
    FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
