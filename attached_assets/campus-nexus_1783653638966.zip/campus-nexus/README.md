# Campus Nexus

*A web-based student boarding finder system for university accommodation.*

## Team Members
- Dinith
- Gimsara
- Thamashi
- Sandali
- Dilmi
- Navodya

![Django](https://img.shields.io/badge/Django-4.2-green) ![DRF](https://img.shields.io/badge/DRF-REST-red) ![MySQL](https://img.shields.io/badge/MySQL-Database-blue) ![JWT](https://img.shields.io/badge/JWT-Auth-yellow) ![Python](https://img.shields.io/badge/Python-47.4%25-blue) ![HTML](https://img.shields.io/badge/HTML-29.3%25-orange) ![JavaScript](https://img.shields.io/badge/JavaScript-15.5%25-yellow) ![CSS](https://img.shields.io/badge/CSS-7.8%25-purple)

> Campus Nexus bridges the gap between students searching for safe, affordable boarding and owners looking to list their spaces — all in one seamless platform.

## Getting Started
This repository contains the front-end assets (JS, CSS) and the database schema (`boarding_finder_db.sql`) for Campus Nexus.
A backend server and HTML templates are required to run the full system fully connected to the database.

## 🏠 Features
✅ **Smart Search & Filters** - Location, price, room type, gender preference  
✅ **Rich Listings** - Photos, amenities (WiFi, meals, parking), maps, ratings/reviews  
✅ **Admin Approval Workflow** - Owners post listings → pending → approved/rejected  
✅ **Student Toolkit** - Bookmarks, secure messaging, detailed views, reviews  
✅ **Owner Dashboard** - Manage listings, view inquiries/bookings/reviews  
✅ **Role-Based Auth** - JWT tokens for students, owners, admins  
✅ **Image Gallery** - Upload multiple photos with thumbnails  
✅ **Responsive Design** - Works on mobile/desktop  

## 👥 User Roles

| Feature | Student ✅ | Owner ✅ | Admin ✅ |
|---------|------------|---------|----------|
| Search/Filter Listings | ✅ | ✅ | ✅ |
| View Details & Reviews | ✅ | ✅ | ✅ |
| Post New Listing | ❌ | ✅ | ✅ |
| Manage Own Listings | ❌ | ✅ | ✅ |
| Approve Listings | ❌ | ❌ | ✅ |
| View Inquiries/Reviews | ✅ (sent) | ✅ (received) | ✅ |
| Write Reviews | ✅ | ❌ | ✅ |
| Bookmark Favorites | ✅ | ❌ | ❌ |
| Secure Messaging | ✅ | ✅ | ❌ |

## ⚙️ Tech Stack

| Layer | Technology | Purpose |
|-------|------------|---------|
| Backend | Django 4.2+ | Core framework & ORM |
| API | Django REST Framework | RESTful endpoints |
| Auth | SimpleJWT | Secure token authentication |
| Database | MySQL | Data storage & relationships |
| Images | Pillow | Uploads & thumbnails |
| Filtering | django-filter | Query parameters |
| CORS | django-cors-headers | Frontend API calls |
| Config | python-decouple | Environment variables |
| Frontend | HTML/CSS/JS + Bootstrap | Responsive UI |

## 📊 Language Composition
- **Python** - 47.4% (Backend & Django)
- **HTML** - 29.3% (Frontend templates)
- **JavaScript** - 15.5% (Frontend interactions)
- **CSS** - 7.8% (Styling)

## 🚀 Installation

### Backend
```bash
cd Backend
pip install -r requirements.txt
cp .env.example .env  # Edit with your credentials
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

### Database
```bash
mysql -u root -p -e "CREATE DATABASE boarding_finder CHARACTER SET utf8mb4;"
mysql -u root -p boarding_finder < ../database/boarding_finder_db.sql
```

### Frontend
- Open `index.html` in browser
- Or serve via Django: copy HTML/CSS/JS to `Backend/templates/static/`

## 🔐 Environment Variables
```env
SECRET_KEY=your-super-secret-key-here-generate-with-django
DEBUG=True
DB_NAME=boarding_finder
DB_USER=root
DB_PASSWORD=your-mysql-password
DB_HOST=localhost
DB_PORT=3306
```

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/listings/` | List approved listings |
| `GET` | `/api/listings/?location=Negombo&price__lte=10000` | Filtered search |
| `POST` | `/api/listings/` | Create listing (owners) |
| `POST` | `/api/auth/login/` | Get JWT access/refresh tokens |
| `GET` | `/api/listings/123/reviews/` | Listing reviews |
| `POST` | `/api/listings/123/reviews/` | Add review (students) |

## 🖥️ Frontend Pages
- **index.html** - Login/Register (Student & Owner tabs)  
- **home.html** - Dashboard with featured listings  
- **search.html** - Live search & filter interface  
- **details.html** - Listing details, gallery, booking info  
- **register.html** - New account signup  
- **reviews.html** - Reviews & ratings for listings  

## 🤝 Contributing
1. 🍴 Fork the repo  
2. 🌱 Create feature branch: `git checkout -b feature/cool-thing`  
3. 💾 Commit: `git commit -m 'Add cool thing'`  
4. 📤 Push: `git push origin feature/cool-thing`  
5. 🎉 Open Pull Request!  

Follow PEP8, add tests, & update this README ❤️

## 📄 License
This project is licensed under the [MIT License](LICENSE).

---

**Made with ❤️ by the Campus Nexus Team**
