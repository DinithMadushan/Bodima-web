# Campus Nexus - Listings Image Upload Extension + Django Setup

## Completed: None

## Pending:
### Phase 1: Django Project Setup
- [x] Create manage.py at root
- [x] Create Backend/settings.py with MEDIA/STATIC, MySQL, JWT, CORS, decouple
- [x] Create Backend/wsgi.py, asgi.py, __init__.py
- [x] Create requirements.txt with Pillow etc.
- [x] Create .env.example

### Phase 2: Listings App Extensions
- [ ] Create listings/permissions.py (IsOwnerOrAdmin)
- [ ] Create listings/utils.py (validate/delete/get_url)
- [ ] Create listings/urls.py (new endpoints)
- [x] Edit Backend/urls.py (include listings.urls)
- [ ] Edit listings/models.py (thumbnail ImageField, ListingImage: image/caption/is_primary)
- [ ] Edit listings/serializers.py (extend with image ser, thumbnail_url)
- [x] Add public CRUD views to listings/views.py (/api/listings/)
- [x] Extend owner_views.py for file upload bulk, delete, primary
- [ ] Run makemigrations listings
- [ ] Run migrate

### Phase 3: Test
- [ ] python manage.py check
- [ ] python manage.py runserver
- [ ] Test POST /api/listings/ with thumbnail
- [ ] Test image upload /images/

