/* ============================================================
   බෝdima.lk — Main JavaScript
   File: js/script.js
   ============================================================ */

/* ── NAVBAR: scroll effect ── */
(function () {
  const nav = document.getElementById('mainNav');
  if (!nav) return;
  window.addEventListener('scroll', function () {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  });
})();

/* ── MOBILE MENU ── */
function openMobileMenu() {
  const menu    = document.getElementById('mobileMenu');
  const overlay = document.getElementById('menuOverlay');
  if (menu)    menu.classList.add('open');
  if (overlay) overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeMobileMenu() {
  const menu    = document.getElementById('mobileMenu');
  const overlay = document.getElementById('menuOverlay');
  if (menu)    menu.classList.remove('open');
  if (overlay) overlay.classList.remove('open');
  document.body.style.overflow = '';
}

/* ── FAVOURITE TOGGLE ── */
document.addEventListener('click', function (e) {
  if (e.target.classList.contains('card-fav') || e.target.closest('.card-fav')) {
    const btn = e.target.classList.contains('card-fav') ? e.target : e.target.closest('.card-fav');
    e.stopPropagation();
    const isFaved = btn.textContent.trim() === '❤️';
    btn.textContent = isFaved ? '🤍' : '❤️';
    btn.title = isFaved ? 'Save to favourites' : 'Remove from favourites';
  }
});

/* ── SCROLL-REVEAL (IntersectionObserver) ── */
(function () {
  const targets = document.querySelectorAll(
    '.property-card, .step-card, .review-card, .value-card, .stat-box, .facility-item'
  );
  if (!targets.length) return;

  const observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.style.opacity  = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  targets.forEach(function (el, i) {
    el.style.opacity    = '0';
    el.style.transform  = 'translateY(24px)';
    el.style.transition = 'opacity .55s ease ' + (i * 0.07) + 's, transform .55s ease ' + (i * 0.07) + 's';
    observer.observe(el);
  });
})();

/* ── PRICE RANGE SLIDER (search.html) ── */
(function () {
  const minSlider  = document.getElementById('minPrice');
  const maxSlider  = document.getElementById('maxPrice');
  const minDisplay = document.getElementById('minDisplay');
  const maxDisplay = document.getElementById('maxDisplay');

  if (!minSlider || !maxSlider) return;

  function updateRange() {
    let min = parseInt(minSlider.value);
    let max = parseInt(maxSlider.value);
    if (min > max) { let t = min; min = max; max = t; }
    if (minDisplay) minDisplay.textContent = 'Rs ' + min.toLocaleString();
    if (maxDisplay) maxDisplay.textContent = 'Rs ' + max.toLocaleString();
  }

  minSlider.addEventListener('input', updateRange);
  maxSlider.addEventListener('input', updateRange);
  updateRange(); // init
})();

/* ── SEARCH LISTINGS FILTER (search.html) ── */
(function () {
  const applyBtn = document.querySelector('.btn-apply-filters');
  if (!applyBtn) return;

  applyBtn.addEventListener('click', function () {
    const minVal = parseInt(document.getElementById('minPrice')?.value || 0);
    const maxVal = parseInt(document.getElementById('maxPrice')?.value || 999999);

    const checkedFacilities = Array.from(
      document.querySelectorAll('.checkbox-group input[type=checkbox]:checked')
    ).map(function (cb) { return cb.id; });

    const cards = document.querySelectorAll('.property-card');
    cards.forEach(function (card) {
      card.style.display = 'flex'; // show all by default
    });

    // Visual feedback
    applyBtn.textContent = '✓ Filters Applied';
    applyBtn.style.background = '#27ae60';
    setTimeout(function () {
      applyBtn.textContent = 'Apply Filters';
      applyBtn.style.background = '';
    }, 1800);
  });
})();

/* ── VIEW TOGGLE (list / grid) ── */
function setView(view) {
  const listBtn   = document.getElementById('listBtn');
  const gridBtn   = document.getElementById('gridBtn');
  const container = document.getElementById('resultsContainer');
  if (!container) return;

  if (listBtn) listBtn.classList.toggle('active', view === 'list');
  if (gridBtn) gridBtn.classList.toggle('active', view === 'grid');

  if (view === 'grid') {
    container.classList.add('grid-view');
    container.classList.remove('list-view');
  } else {
    container.classList.add('list-view');
    container.classList.remove('grid-view');
  }
}

/* ── REVIEW TAB FILTER (reviews.html) ── */
(function () {
  const tabs = document.querySelectorAll('.filter-tab');
  if (!tabs.length) return;
  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      tabs.forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
    });
  });
})();

/* ── LOGIN / REGISTER TAB SWITCH (index.html) ── */
function switchTab(tab) {
  const loginTab    = document.getElementById('loginTab');
  const registerTab = document.getElementById('registerTab');
  const loginForm   = document.getElementById('loginForm');
  const regForm     = document.getElementById('registerForm');
  const hint        = document.getElementById('switchHint');

  const isLogin = tab === 'login';
  if (loginTab)    loginTab.classList.toggle('active', isLogin);
  if (registerTab) registerTab.classList.toggle('active', !isLogin);
  if (loginForm)   loginForm.style.display   = isLogin ? 'block' : 'none';
  if (regForm)     regForm.style.display     = isLogin ? 'none'  : 'block';
  if (hint) {
    hint.innerHTML = isLogin
      ? 'Don\'t have an account? <a href="#" onclick="switchTab(\'register\');return false;">Register free</a>'
      : 'Already have an account? <a href="#" onclick="switchTab(\'login\');return false;">Sign in</a>';
  }
}

/* ── SMOOTH SCROLL for anchor links ── */
document.addEventListener('click', function (e) {
  const link = e.target.closest('a[href^="#"]');
  if (!link) return;
  const target = document.querySelector(link.getAttribute('href'));
  if (target) {
    e.preventDefault();
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});

/* ── SEARCH REDIRECT (home hero) ── */
function heroSearch() {
  const loc    = document.getElementById('heroLocation')?.value || '';
  const budget = document.getElementById('heroBudget')?.value   || '';
  const type   = document.getElementById('heroType')?.value     || '';

  const params = new URLSearchParams();
  if (loc)    params.set('location', loc);
  if (budget) params.set('budget', budget);
  if (type)   params.set('type', type);

  window.location.href = 'search.html' + (params.toString() ? '?' + params.toString() : '');
}

/* ── ACTIVE NAV LINK highlight ── */
(function () {
  const current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(function (link) {
    const href = link.getAttribute('href');
    if (href === current) link.classList.add('active');
  });
})();

/* ============================================================
   API INTEGRATION — added by Campus Nexus integration layer
   Dynamically loads js/api.js so all pages get API support
   without modifying any HTML file.
   ============================================================ */
(function () {
  // Inject api.js before this script runs on any page
  if (!window.__cn_api_loaded) {
    window.__cn_api_loaded = true;
    var s = document.createElement('script');
    s.src = (document.querySelector('script[src*="js/script.js"]')
      ? '' : '../') + 'js/api.js';
    s.async = false;
    document.head.appendChild(s);
  }
})();

/* ── Override: Apply Filters button triggers live API search ── */
(function () {
  // Wait for DOM + api.js to be ready
  function wireSearch() {
    const applyBtn = document.querySelector('.btn-apply-filters');
    if (!applyBtn || applyBtn._apiWired) return;
    applyBtn._apiWired = true;

    applyBtn.addEventListener('click', async function () {
      if (typeof window.CampusNexus === 'undefined') return;
      // CampusNexus.initSearchPage handles the full search
      // Just trigger it if we're on search.html
      const page = window.location.pathname.split('/').pop();
      if (page === 'search.html' && typeof initSearchPage === 'function') {
        // Already wired by api.js DOMContentLoaded — no double-trigger needed
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wireSearch);
  } else {
    wireSearch();
  }
})();
