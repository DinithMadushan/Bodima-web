/* ============================================================
   Campus Nexus — API Client
   File: js/api.js

   Central module for all backend API calls.
   Loaded by: index.html, home.html, search.html, details.html

   Token storage: localStorage (access + refresh)
   Base URL:      configurable via window.API_BASE_URL
   ============================================================ */

const API_BASE = (window.API_BASE_URL || 'http://127.0.0.1:8000');

/* ── Token helpers ─────────────────────────────────────────── */
const Auth = {
  getAccess:  () => localStorage.getItem('cn_access'),
  getRefresh: () => localStorage.getItem('cn_refresh'),
  getUser:    () => { try { return JSON.parse(localStorage.getItem('cn_user') || 'null'); } catch { return null; } },
  setTokens:  (access, refresh) => {
    localStorage.setItem('cn_access',  access);
    localStorage.setItem('cn_refresh', refresh);
  },
  setUser: (data) => localStorage.setItem('cn_user', JSON.stringify(data)),
  clear:   () => { ['cn_access','cn_refresh','cn_user'].forEach(k => localStorage.removeItem(k)); },
  isLoggedIn: () => !!localStorage.getItem('cn_access'),
  getRole: () => { const u = Auth.getUser(); return u ? u.role : null; },
};

/* ── HTTP helper ─────────────────────────────────────────────
   Handles JWT auth header, JSON body, token auto-refresh.    */
async function api(method, path, body, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = Auth.getAccess();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const config = {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    ...opts,
  };

  let res = await fetch(`${API_BASE}${path}`, config);

  // Auto-refresh on 401
  if (res.status === 401 && Auth.getRefresh()) {
    const refreshed = await fetch(`${API_BASE}/api/auth/token/refresh/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh: Auth.getRefresh() }),
    });
    if (refreshed.ok) {
      const data = await refreshed.json();
      Auth.setTokens(data.access, Auth.getRefresh());
      headers['Authorization'] = `Bearer ${data.access}`;
      res = await fetch(`${API_BASE}${path}`, { ...config, headers });
    } else {
      Auth.clear();
      window.location.href = 'index.html';
      return;
    }
  }

  return res;
}

/* ── API modules ─────────────────────────────────────────────*/

/* Auth */
const AuthAPI = {
  async login(email, password) {
    const res = await api('POST', '/api/auth/login/', { email, password });
    const data = await res.json();
    if (res.ok) {
      Auth.setTokens(data.access, data.refresh);
      Auth.setUser({ full_name: data.full_name, role: data.role });
    }
    return { ok: res.ok, data };
  },

  async register(payload) {
    const res  = await api('POST', '/api/auth/register/', payload);
    const data = await res.json();
    return { ok: res.ok, data };
  },

  async logout() {
    const refresh = Auth.getRefresh();
    if (refresh) await api('POST', '/api/auth/logout/', { refresh });
    Auth.clear();
  },
};

/* Listings */
const ListingsAPI = {
  async search(params = {}) {
    const qs  = new URLSearchParams(params).toString();
    const res = await api('GET', `/api/listings/search/${qs ? '?' + qs : ''}`);
    return res.ok ? await res.json() : [];
  },

  async featured() {
    const res = await api('GET', '/api/listings/featured/');
    return res.ok ? await res.json() : [];
  },

  async detail(id) {
    const res = await api('GET', `/api/listings/${id}/`);
    return { ok: res.ok, data: await res.json() };
  },

  async create(formData) {
    const token = Auth.getAccess();
    const res   = await fetch(`${API_BASE}/api/listings/`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body:   formData,  // FormData for file upload
    });
    return { ok: res.ok, data: await res.json() };
  },

  async update(id, payload) {
    const res = await api('PATCH', `/api/owner/listings/${id}/`, payload);
    return { ok: res.ok, data: await res.json() };
  },

  async delete(id) {
    const res = await api('DELETE', `/api/listings/${id}/`);
    return { ok: res.ok };
  },

  async uploadImages(listingId, files, captions = []) {
    const fd    = new FormData();
    files.forEach((f, i) => {
      fd.append('images', f);
      fd.append('captions', captions[i] || '');
    });
    const token = Auth.getAccess();
    const res   = await fetch(`${API_BASE}/api/listings/${listingId}/images/`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body:   fd,
    });
    return { ok: res.ok, data: await res.json() };
  },
};

/* Bookings */
const BookingsAPI = {
  async create(listingId, moveInDate, message = '') {
    const res = await api('POST', '/api/bookings/create/', {
      listing: listingId, move_in_date: moveInDate, message,
    });
    return { ok: res.ok, data: await res.json() };
  },

  async list() {
    const res = await api('GET', '/api/bookings/');
    return res.ok ? await res.json() : [];
  },

  async receipt(bookingId) {
    const res = await api('GET', `/api/bookings/${bookingId}/receipt/`);
    return { ok: res.ok, data: await res.json() };
  },

  async ownerList() {
    const res = await api('GET', '/api/owner/bookings/');
    return res.ok ? await res.json() : [];
  },

  async confirm(bookingId, newStatus) {
    const res = await api('PATCH', `/api/owner/bookings/${bookingId}/`, { status: newStatus });
    return { ok: res.ok, data: await res.json() };
  },
};

/* Payments */
const PaymentsAPI = {
  async stripeCreateIntent(bookingId, paymentType = 'deposit') {
    const res = await api('POST', '/api/payments/stripe/create/', {
      booking_id: bookingId, payment_type: paymentType,
    });
    return { ok: res.ok, data: await res.json() };
  },

  async stripeConfirm(paymentId, paymentIntentId) {
    const res = await api('POST', '/api/payments/stripe/confirm/', {
      payment_id: paymentId, payment_intent_id: paymentIntentId,
    });
    return { ok: res.ok, data: await res.json() };
  },

  async paypalCreate(bookingId, paymentType = 'deposit') {
    const res = await api('POST', '/api/payments/paypal/create/', {
      booking_id: bookingId, payment_type: paymentType,
    });
    return { ok: res.ok, data: await res.json() };
  },

  async paypalCapture(orderId, payerId) {
    const res = await api('POST', `/api/payments/paypal/capture/${orderId}/`, { payer_id: payerId });
    return { ok: res.ok, data: await res.json() };
  },

  async history() {
    const res = await api('GET', '/api/payments/history/');
    return res.ok ? await res.json() : [];
  },

  async statusForBooking(bookingId) {
    const res = await api('GET', `/api/payments/${bookingId}/`);
    return res.ok ? await res.json() : [];
  },
};

/* Messaging */
const MessagingAPI = {
  async conversations() {
    const res = await api('GET', '/api/messages/conversations/');
    return res.ok ? await res.json() : [];
  },

  async startOrGet(listingId) {
    const res = await api('POST', '/api/messages/conversations/', { listing_id: listingId });
    return { ok: res.ok, data: await res.json() };
  },

  async getConversation(id) {
    const res = await api('GET', `/api/messages/conversations/${id}/`);
    return { ok: res.ok, data: await res.json() };
  },

  async send(conversationId, body) {
    const res = await api('POST', `/api/messages/conversations/${conversationId}/send/`, { body });
    return { ok: res.ok, data: await res.json() };
  },

  async markRead(conversationId) {
    const res = await api('PATCH', `/api/messages/conversations/${conversationId}/read/`);
    return res.ok;
  },

  async unreadCount() {
    const res = await api('GET', '/api/messages/unread/');
    return res.ok ? (await res.json()).unread : 0;
  },
};

/* Reviews */
const ReviewsAPI = {
  async list(listingId) {
    const res = await api('GET', `/api/reviews/?listing=${listingId}`);
    return res.ok ? await res.json() : [];
  },
  async create(listingId, rating, comment) {
    const res = await api('POST', '/api/reviews/create/', { listing: listingId, rating, comment });
    return { ok: res.ok, data: await res.json() };
  },
};

/* Admin */
const AdminAPI = {
  async listings(status_ = 'pending') {
    const res = await api('GET', '/api/admin/listings/');
    return res.ok ? await res.json() : [];
  },
  async approveListing(id, newStatus) {
    const res = await api('PATCH', `/api/admin/listings/${id}/`, { status: newStatus });
    return { ok: res.ok, data: await res.json() };
  },
  async users(params = {}) {
    const qs  = new URLSearchParams(params).toString();
    const res = await api('GET', `/api/admin/users/${qs ? '?' + qs : ''}`);
    return res.ok ? await res.json() : [];
  },
  async updateUser(id, payload) {
    const res = await api('PATCH', `/api/admin/users/${id}/`, payload);
    return { ok: res.ok, data: await res.json() };
  },
  async payments(params = {}) {
    const qs  = new URLSearchParams(params).toString();
    const res = await api('GET', `/api/admin/payments/${qs ? '?' + qs : ''}`);
    return res.ok ? await res.json() : [];
  },
};

/* ── UI Helpers ──────────────────────────────────────────────*/
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  const colors = { success: '#27ae60', error: '#e74c3c', info: '#1a3c5e', warning: '#f39c12' };
  toast.style.cssText = `
    position:fixed;bottom:24px;right:24px;z-index:9999;padding:14px 22px;
    background:${colors[type] || colors.info};color:#fff;border-radius:8px;
    font-size:0.95rem;box-shadow:0 4px 18px rgba(0,0,0,.2);
    animation:slideUp .3s ease;max-width:340px;line-height:1.4;
  `;
  toast.textContent = message;
  if (!document.getElementById('toast-style')) {
    const s = document.createElement('style');
    s.id = 'toast-style';
    s.textContent = '@keyframes slideUp{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}';
    document.head.appendChild(s);
  }
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

function buildPropertyCard(listing) {
  const imgSrc = listing.thumbnail_url || listing.img || 'images/bodima_logo-removebg-preview.png';
  const amenityHTML = (listing.amenities || []).slice(0, 4)
    .map(a => `<span class="amenity-tag">${a}</span>`).join('');
  return `
    <div class="property-card" onclick="window.location.href='details.html?id=${listing.id}'">
      <div class="card-img-wrapper">
        <img src="${imgSrc}" alt="${listing.name}" class="card-img" loading="lazy">
        ${listing.badge ? `<div class="card-badge ${listing.badge.toLowerCase().replace(' ','-')}">${listing.badge}</div>` : ''}
        <button class="card-fav" title="Save to favourites" onclick="event.stopPropagation()">🤍</button>
      </div>
      <div class="card-body">
        <h3 class="card-title">${listing.name}</h3>
        <p class="card-location">📍 ${listing.area}</p>
        <p class="card-price">Rs ${Number(listing.price).toLocaleString()}<span>/month</span></p>
        <div class="card-amenities">${amenityHTML}</div>
        <div class="card-footer">
          <span class="card-rating">⭐ ${listing.rating || '—'} (${listing.reviews || 0})</span>
          <a href="details.html?id=${listing.id}" class="card-link btn-primary">View Details →</a>
        </div>
      </div>
    </div>`;
}

/* ── Page-level init functions ───────────────────────────────*/

/* index.html — Login + Register forms */
function initAuthPage() {
  const loginForm = document.getElementById('loginForm');
  const regForm   = document.getElementById('registerForm');

  if (loginForm) {
    const loginBtn = loginForm.querySelector('button') ||
                     loginForm.closest('.auth-card')?.querySelector('.btn-login');

    // Find button in parent container
    const btn = document.querySelector('.btn-login');
    if (btn) {
      btn.addEventListener('click', async function (e) {
        e.preventDefault();
        const emailInput = loginForm.querySelector('input[type="email"]');
        const passInput  = loginForm.querySelector('input[type="password"]');
        if (!emailInput || !passInput) return;

        btn.textContent = 'Signing in…';
        btn.disabled    = true;

        const { ok, data } = await AuthAPI.login(emailInput.value.trim(), passInput.value);

        if (ok) {
          showToast(`Welcome back, ${data.full_name}!`, 'success');
          setTimeout(() => {
            const dest = { student: 'home.html', owner: 'home.html', admin: 'home.html' };
            window.location.href = dest[data.role] || 'home.html';
          }, 800);
        } else {
          showToast(data.detail || 'Invalid credentials.', 'error');
          btn.textContent = 'Sign In →';
          btn.disabled    = false;
        }
      });
    }
  }

  if (regForm) {
    const regBtn = document.querySelector('.btn-register') ||
                   regForm.querySelector('button');
    if (regBtn) {
      regBtn.addEventListener('click', async function (e) {
        e.preventDefault();
        const inputs = regForm.querySelectorAll('input');
        const select = regForm.querySelector('select');

        // Map inputs by placeholder
        const get = (placeholder) => {
          for (const inp of inputs) {
            if (inp.placeholder && inp.placeholder.toLowerCase().includes(placeholder.toLowerCase()))
              return inp.value.trim();
          }
          return '';
        };

        const fullName = get('Full Name').split(' ');
        const email    = get('Email');
        const password = get('Password');
        const role     = select ? select.value : 'student';

        if (!email || !password) {
          showToast('Email and password are required.', 'warning'); return;
        }

        const payload = {
          first_name: fullName[0] || 'User',
          last_name:  fullName.slice(1).join(' ') || '',
          email, password, role,
        };

        regBtn.textContent = 'Creating account…';
        regBtn.disabled    = true;

        const { ok, data } = await AuthAPI.register(payload);
        if (ok) {
          showToast('Account created! Please sign in.', 'success');
          if (typeof switchTab === 'function') switchTab('login');
        } else {
          const msg = Object.values(data).flat().join(' ');
          showToast(msg || 'Registration failed.', 'error');
        }
        regBtn.textContent = 'Create Account';
        regBtn.disabled    = false;
      });
    }
  }
}

/* home.html — Featured listings */
async function initHomePage() {
  const container = document.querySelector('.property-cards') ||
                    document.querySelector('.featured-grid');
  if (!container) return;

  const listings = await ListingsAPI.featured();
  if (!listings.length) return;

  container.innerHTML = listings.map(buildPropertyCard).join('');
}

/* search.html — Live search with filters */
async function initSearchPage() {
  const container = document.getElementById('resultsContainer');
  if (!container) return;

  async function runSearch() {
    const params = {};
    const q    = document.getElementById('searchInput')?.value?.trim();
    const loc  = document.querySelector('select[name="location"]')?.value ||
                 document.getElementById('locationFilter')?.value;
    const type = document.querySelector('select[name="type"]')?.value;
    const gend = document.querySelector('select[name="gender"]')?.value;
    const sort = document.getElementById('sortSelect')?.value;
    const min  = document.getElementById('minPrice')?.value;
    const max  = document.getElementById('maxPrice')?.value;

    if (q)    params.q         = q;
    if (loc)  params.location  = loc;
    if (type) params.type      = type;
    if (gend) params.gender    = gend;
    if (sort) params.sort      = sort;
    if (min)  params.min_price = min;
    if (max)  params.max_price = max;

    const amenities = Array.from(
      document.querySelectorAll('.checkbox-group input[type=checkbox]:checked')
    ).map(cb => cb.id || cb.value).filter(Boolean);
    if (amenities.length) params.amenities = amenities.join(',');

    const count = document.getElementById('resultCount') ||
                  document.querySelector('.result-count');
    if (count) count.textContent = 'Searching…';

    const listings = await ListingsAPI.search(params);

    if (!listings.length) {
      container.innerHTML = `<div class="no-results" style="text-align:center;padding:60px;color:#666;">
        <div style="font-size:3rem">🏠</div>
        <h3>No listings found</h3>
        <p>Try adjusting your filters.</p>
      </div>`;
      if (count) count.textContent = '0 results';
      return;
    }

    container.innerHTML = listings.map(buildPropertyCard).join('');
    if (count) count.textContent = `${listings.length} result${listings.length !== 1 ? 's' : ''} found`;
  }

  // Run on page load (picks up URL params)
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('location')) {
    const sel = document.querySelector('select[name="location"]');
    if (sel) sel.value = urlParams.get('location');
  }
  if (urlParams.get('type')) {
    const sel = document.querySelector('select[name="type"]');
    if (sel) sel.value = urlParams.get('type');
  }
  await runSearch();

  // Wire apply-filters button
  const applyBtn = document.querySelector('.btn-apply-filters');
  if (applyBtn) applyBtn.addEventListener('click', runSearch);

  // Sort dropdown
  const sortSel = document.getElementById('sortSelect');
  if (sortSel) sortSel.addEventListener('change', runSearch);
}

/* details.html — Listing detail, booking, messaging, payment */
async function initDetailsPage() {
  const params    = new URLSearchParams(window.location.search);
  const listingId = params.get('id');
  if (!listingId) return;

  const { ok, data: listing } = await ListingsAPI.detail(listingId);
  if (!ok) { showToast('Listing not found.', 'error'); return; }

  // Update page title
  document.title = `${listing.name} — Campus Nexus`;

  // Fill hero / title areas if elements exist
  const nameEl = document.querySelector('.listing-name, .detail-title, h1.property-title');
  if (nameEl) nameEl.textContent = listing.name;

  const areaEl = document.querySelector('.listing-area, .detail-location');
  if (areaEl) areaEl.textContent = `📍 ${listing.area}`;

  const priceEl = document.querySelector('.listing-price, .detail-price, .card-price');
  if (priceEl) priceEl.innerHTML = `Rs ${Number(listing.price).toLocaleString()}<span>/month</span>`;

  // Gallery images
  const gallery = document.querySelector('.gallery, .property-gallery, .detail-images');
  if (gallery && listing.images && listing.images.length) {
    gallery.innerHTML = listing.images.map(img =>
      `<img src="${img.image_url}" alt="${img.caption || listing.name}" class="gallery-img" loading="lazy">`
    ).join('');
  }

  // Booking card fields
  const typeEl     = document.querySelector('[data-field="type"]');
  const depositEl  = document.querySelector('[data-field="deposit"]');
  const mealsEl    = document.querySelector('[data-field="meals"]');
  const wifiEl     = document.querySelector('[data-field="wifi"]');
  const availEl    = document.querySelector('[data-field="available_from"]');
  if (typeEl)    typeEl.textContent     = listing.type;
  if (depositEl) depositEl.textContent  = `Rs ${(listing.price * listing.deposit_months).toLocaleString()}`;
  if (mealsEl)   mealsEl.textContent    = listing.meals_included ? '✅ Included' : '❌ Not Included';
  if (wifiEl)    wifiEl.textContent     = listing.wifi_included  ? '✅ Included' : '❌ Not Included';
  if (availEl)   availEl.textContent    = listing.available_from;

  // ── Book / Visit button ─────────────────────────────────────
  const bookBtn = document.querySelector('.btn-book');
  if (bookBtn) {
    bookBtn.addEventListener('click', async function () {
      if (!Auth.isLoggedIn()) {
        showToast('Please sign in to make a booking.', 'warning');
        setTimeout(() => { window.location.href = 'index.html'; }, 1000);
        return;
      }
      const moveIn = prompt('Enter your desired move-in date (YYYY-MM-DD):');
      if (!moveIn) return;
      const msg = prompt('Any message to the owner? (optional)') || '';

      bookBtn.textContent = 'Sending…';
      bookBtn.disabled = true;

      const { ok: bOk, data: bData } = await BookingsAPI.create(listingId, moveIn, msg);
      if (bOk) {
        showToast('Booking request sent! The owner will confirm shortly.', 'success');
      } else {
        showToast(bData.detail || 'Booking failed.', 'error');
      }
      bookBtn.textContent = '📞 Request to Visit';
      bookBtn.disabled = false;
    });
  }

  // ── Message Owner button ─────────────────────────────────────
  const contactBtn = document.querySelector('.btn-contact');
  if (contactBtn) {
    contactBtn.addEventListener('click', async function () {
      if (!Auth.isLoggedIn()) {
        showToast('Please sign in to message the owner.', 'warning');
        setTimeout(() => { window.location.href = 'index.html'; }, 1000);
        return;
      }
      if (Auth.getRole() !== 'student') {
        showToast('Only students can message owners.', 'warning');
        return;
      }

      const msg = prompt('Type your message to the owner:');
      if (!msg || !msg.trim()) return;

      contactBtn.textContent = 'Sending…';
      contactBtn.disabled = true;

      // Start/get conversation
      const { ok: cOk, data: conv } = await MessagingAPI.startOrGet(listingId);
      if (!cOk) {
        showToast('Could not open conversation.', 'error');
        contactBtn.textContent = '💬 Message Owner';
        contactBtn.disabled = false;
        return;
      }

      // Send message
      const { ok: mOk } = await MessagingAPI.send(conv.id, msg.trim());
      if (mOk) {
        showToast('Message sent to owner!', 'success');
      } else {
        showToast('Failed to send message.', 'error');
      }
      contactBtn.textContent = '💬 Message Owner';
      contactBtn.disabled = false;
    });
  }

  // ── Pay Now button (if it exists on the page) ─────────────────
  const payBtn = document.querySelector('.btn-pay, .btn-payment, [data-action="pay"]');
  if (payBtn) {
    payBtn.addEventListener('click', async function () {
      if (!Auth.isLoggedIn()) {
        showToast('Please sign in to make a payment.', 'warning'); return;
      }
      const bookingId = payBtn.dataset.bookingId;
      if (!bookingId) { showToast('No booking selected.', 'warning'); return; }

      const method = confirm('Pay with Stripe (card)? Click Cancel for PayPal.') ? 'stripe' : 'paypal';
      if (method === 'stripe') {
        await handleStripePayment(bookingId);
      } else {
        await handlePayPalPayment(bookingId);
      }
    });
  }
}

/* ── Stripe payment flow ───────────────────────────────────── */
async function handleStripePayment(bookingId, paymentType = 'deposit') {
  const { ok, data } = await PaymentsAPI.stripeCreateIntent(bookingId, paymentType);
  if (!ok) { showToast(data.detail || 'Payment setup failed.', 'error'); return; }

  const stripeKey = window.STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder';

  // Check if Stripe.js is loaded
  if (typeof Stripe === 'undefined') {
    const script = document.createElement('script');
    script.src = 'https://js.stripe.com/v3/';
    document.head.appendChild(script);
    await new Promise(resolve => { script.onload = resolve; });
  }

  const stripe  = Stripe(stripeKey);
  const elements = stripe.elements();
  const card     = elements.create('card', {
    style: {
      base: { fontSize: '16px', color: '#1a3c5e', fontFamily: 'inherit' },
    },
  });

  // Create a modal overlay for card entry
  const modal = document.createElement('div');
  modal.id = 'stripe-modal';
  modal.innerHTML = `
    <div style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:10000;display:flex;align-items:center;justify-content:center">
      <div style="background:#fff;border-radius:12px;padding:32px;width:420px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.3)">
        <h3 style="margin:0 0 8px;color:#1a3c5e">💳 Pay with Card</h3>
        <p style="color:#666;margin:0 0 20px;font-size:.9rem">Amount: Rs ${Number(data.amount).toLocaleString()}</p>
        <div id="stripe-card-element" style="border:1.5px solid #ddd;border-radius:8px;padding:12px 14px;margin-bottom:16px"></div>
        <div id="stripe-errors" style="color:#e74c3c;font-size:.85rem;margin-bottom:12px;min-height:18px"></div>
        <div style="display:flex;gap:10px">
          <button id="stripe-pay-btn" style="flex:1;padding:12px;background:#1a3c5e;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:1rem">Pay Now</button>
          <button id="stripe-cancel-btn" style="padding:12px 18px;background:#f5f5f5;border:none;border-radius:8px;cursor:pointer">Cancel</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(modal);
  card.mount('#stripe-card-element');

  document.getElementById('stripe-cancel-btn').onclick = () => modal.remove();

  document.getElementById('stripe-pay-btn').onclick = async function () {
    this.textContent = 'Processing…';
    this.disabled = true;

    const { paymentIntent, error } = await stripe.confirmCardPayment(data.client_secret, {
      payment_method: { card },
    });

    if (error) {
      document.getElementById('stripe-errors').textContent = error.message;
      this.textContent = 'Pay Now';
      this.disabled = false;
    } else if (paymentIntent.status === 'succeeded') {
      modal.remove();
      await PaymentsAPI.stripeConfirm(data.payment_id, paymentIntent.id);
      showToast('Payment successful! 🎉', 'success');
    }
  };
}

/* ── PayPal payment flow ──────────────────────────────────── */
async function handlePayPalPayment(bookingId, paymentType = 'deposit') {
  const { ok, data } = await PaymentsAPI.paypalCreate(bookingId, paymentType);
  if (!ok) { showToast(data.detail || 'PayPal setup failed.', 'error'); return; }

  // Redirect to PayPal approval page
  if (data.approve_url) {
    showToast('Redirecting to PayPal…', 'info');
    sessionStorage.setItem('cn_paypal_payment_id', data.payment_id);
    sessionStorage.setItem('cn_paypal_order_id',   data.order_id);
    setTimeout(() => { window.location.href = data.approve_url; }, 800);
  }
}

/* ── Handle PayPal return ─────────────────────────────────── */
async function handlePayPalReturn() {
  const params  = new URLSearchParams(window.location.search);
  const payerId = params.get('PayerID');
  const orderId = sessionStorage.getItem('cn_paypal_order_id');

  if (payerId && orderId) {
    const { ok, data } = await PaymentsAPI.paypalCapture(orderId, payerId);
    sessionStorage.removeItem('cn_paypal_payment_id');
    sessionStorage.removeItem('cn_paypal_order_id');
    if (ok && data.status === 'completed') {
      showToast('PayPal payment successful! 🎉', 'success');
    } else {
      showToast('PayPal payment failed.', 'error');
    }
  }
}

/* ── Unread message badge ─────────────────────────────────── */
async function initUnreadBadge() {
  if (!Auth.isLoggedIn()) return;
  const count = await MessagingAPI.unreadCount();
  if (count > 0) {
    document.querySelectorAll('.msg-badge, [data-msg-badge]').forEach(el => {
      el.textContent = count;
      el.style.display = 'inline-block';
    });
  }
}

/* ── Update nav for auth state ────────────────────────────── */
function updateNavForAuth() {
  const user     = Auth.getUser();
  const loggedIn = !!user;

  // Show/hide auth-dependent nav items
  document.querySelectorAll('[data-auth="required"]').forEach(el => {
    el.style.display = loggedIn ? '' : 'none';
  });
  document.querySelectorAll('[data-auth="guest"]').forEach(el => {
    el.style.display = loggedIn ? 'none' : '';
  });

  // Logout buttons
  document.querySelectorAll('[data-action="logout"]').forEach(btn => {
    btn.addEventListener('click', async function (e) {
      e.preventDefault();
      await AuthAPI.logout();
      showToast('Signed out.', 'info');
      setTimeout(() => { window.location.href = 'index.html'; }, 600);
    });
  });

  // User greeting
  const greet = document.getElementById('userGreeting');
  if (greet && user) greet.textContent = `Hi, ${user.full_name.split(' ')[0]}`;
}

/* ── Auto-init on DOMContentLoaded ───────────────────────────*/
document.addEventListener('DOMContentLoaded', function () {
  updateNavForAuth();
  initUnreadBadge();

  const page = window.location.pathname.split('/').pop() || 'index.html';

  if (page === 'index.html' || page === '')    initAuthPage();
  if (page === 'home.html')                    initHomePage();
  if (page === 'search.html')                  initSearchPage();
  if (page === 'details.html')                 initDetailsPage();
  if (page === 'payment-success.html')         handlePayPalReturn();
});

/* Export for inline scripts */
window.CampusNexus = {
  Auth, AuthAPI, ListingsAPI, BookingsAPI, PaymentsAPI,
  MessagingAPI, ReviewsAPI, AdminAPI,
  showToast, buildPropertyCard,
  handleStripePayment, handlePayPalPayment,
};
