# Campus Nexus — Security Audit Report
**Scope:** Encryption, JWT handling, GDPR compliance  
**Date:** 2026-05-12  
**Codebase:** Django REST + Vanilla JS frontend (boarding listings platform)

---

## Summary

| Severity | Count |
|---|---|
| 🔴 Critical | 4 |
| 🟠 High | 5 |
| 🟡 Medium | 5 |
| 🔵 Low / Informational | 3 |

---

## 🔴 Critical

### C1 — Stripe `client_secret` Stored in Plaintext in Database

**File:** `Backend/payments/models.py:53`, `payments/views.py`

The `stripe_client_secret` field is persisted to the `payments` table in plaintext:

```python
stripe_client_secret = models.CharField(max_length=500, blank=True, null=True)
```

A Stripe `client_secret` authorises anyone who holds it to complete or query a PaymentIntent — it is a live payment credential, not a reference ID. Storing it in the database means a SQL injection, a leaked backup, or a misconfigured admin panel exposes active payment credentials for every pending transaction.

**Fix:**  
Do not store `client_secret` at all. The frontend only needs it at the moment of creation. Return it in the API response and discard it server-side. Store only `stripe_payment_intent_id` (the `pi_…` reference) for webhook reconciliation:

```python
# views.py — return but never persist
return Response({
    "payment_id":    payment.id,
    "client_secret": intent["client_secret"],  # one-time, not stored
})

# models.py — remove this field entirely
# stripe_client_secret = models.CharField(...)  ← DELETE
```

---

### C2 — JWT Token Blacklisting Not Wired Up — Logout Is Ineffective

**File:** `Backend/settings.py`, `users/views.py`

`LogoutView` calls `token.blacklist()`, but `rest_framework_simplejwt.token_blacklist` is **not listed in `INSTALLED_APPS`**. Without it, the blacklist database tables don't exist and the call silently does nothing (or raises an `AppRegistryNotReady` error at runtime depending on the Django version). Any "logged-out" token remains valid for its full 24-hour lifetime.

**Fix:**

```python
# settings.py
INSTALLED_APPS = [
    ...
    'rest_framework_simplejwt.token_blacklist',  # ADD THIS
]
```

Then run `python manage.py migrate` to create the blacklist tables.

---

### C3 — JWT Access Tokens Stored in `localStorage` — XSS-Accessible

**File:** `js/api.js:17–23`

Both `access` and `refresh` tokens are written to `localStorage`. Any XSS payload can read them with `localStorage.getItem('cn_access')` and impersonate any user indefinitely (refresh tokens survive for 7 days).

**Fix:**  
Store tokens in `httpOnly`, `SameSite=Strict` cookies set by the server. `localStorage` is readable by any JavaScript on the page; `httpOnly` cookies are not.

```python
# views.py — set tokens as cookies instead of response body
response = Response({...})
response.set_cookie('cn_access', str(refresh.access_token),
    httponly=True, secure=True, samesite='Strict',
    max_age=86400)
response.set_cookie('cn_refresh', str(refresh),
    httponly=True, secure=True, samesite='Strict',
    max_age=604800)
return response
```

If switching to cookies is a larger refactor, at minimum shorten `ACCESS_TOKEN_LIFETIME` to 15 minutes and do not store the refresh token in `localStorage` at all.

---

### C4 — `CORS_ALLOW_ALL_ORIGINS = True` + `CORS_ALLOW_CREDENTIALS = True`

**File:** `Backend/settings.py:161–162`

This combination is explicitly warned against in the `django-cors-headers` docs. It allows any origin to make credentialed cross-site requests, effectively defeating Same-Origin Policy for every endpoint. Combined with `localStorage` token storage (C3), this is a direct CSRF/CORS-based account takeover vector.

**Fix:**

```python
CORS_ALLOW_ALL_ORIGINS = False
CORS_ALLOW_CREDENTIALS = True
CORS_ALLOWED_ORIGINS = [
    "https://campusnexus.lk",
    "http://127.0.0.1:5500",  # dev only
]
```

---

## 🟠 High

### H1 — No Rate Limiting on Login Endpoint — Brute Force Possible

**File:** `users/views.py` (LoginView), `settings.py`

There is no throttling on `POST /api/auth/login/`. An attacker can try unlimited password guesses against any email address. There is also no account lockout mechanism.

**Fix:**

```python
# settings.py
REST_FRAMEWORK = {
    ...
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '5/min',
        'user': '100/day',
    },
}
```

For login specifically, use a tighter `ScopedRateThrottle` (e.g. `3/min` per IP). Consider `django-axes` or `django-defender` for lockout after N failures.

---

### H2 — `ALLOWED_HOSTS = ['*']` and Missing HTTPS/Security Headers

**File:** `Backend/settings.py:21, 160+`

`ALLOWED_HOSTS = ['*']` accepts requests with any `Host` header, enabling Host header injection attacks. There are also no HTTPS enforcement settings or security response headers.

**Fix:**

```python
ALLOWED_HOSTS = ['campusnexus.lk', 'www.campusnexus.lk']

# Add for production
SECURE_SSL_REDIRECT = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = 'DENY'
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
```

---

### H3 — Image Upload: `content_type` Is Client-Controlled

**File:** `Backend/listings/utils.py:14–15`

The MIME type check (`file_obj.content_type`) reads the value supplied by the HTTP client — not the actual file bytes. An attacker can rename a PHP webshell to `exploit.jpg`, set `Content-Type: image/jpeg`, and bypass this check. PIL's `img.verify()` helps but does not prevent polyglot files (valid images that also contain executable code).

**Fix:**  
Use `python-magic` to read the actual file magic bytes, and re-seek after verify:

```python
import magic

def validate_image_file(file_obj, max_size_mb=5):
    data = file_obj.read(2048)
    file_obj.seek(0)
    
    mime = magic.from_buffer(data, mime=True)
    allowed = {'image/jpeg', 'image/png', 'image/webp'}
    if mime not in allowed:
        raise ValidationError('Unsupported file type.')
    
    if file_obj.size > max_size_mb * 1024 * 1024:
        raise ValidationError(f'File too large. Max: {max_size_mb}MB.')
    
    try:
        img = Image.open(file_obj)
        img.verify()
        file_obj.seek(0)
    except Exception:
        raise ValidationError('Invalid image data.')
```

---

### H4 — JWT Access Token Lifetime Is 24 Hours

**File:** `Backend/settings.py`

```python
'ACCESS_TOKEN_LIFETIME': timedelta(days=1),
```

A 24-hour access token means a stolen token (via XSS, network sniffing, or log leakage) grants attacker access for up to a day with no revocation mechanism (especially given C2). Industry standard is 5–15 minutes for access tokens.

**Fix:**

```python
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME':  timedelta(minutes=15),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS':  True,
    'BLACKLIST_AFTER_ROTATION': True,  # requires token_blacklist app (see C2)
}
```

---

### H5 — Stripe Error Details Leaked to Client

**File:** `Backend/payments/views.py`

```python
except stripe.error.StripeError as e:
    return Response({"detail": str(e)}, status=status.HTTP_502_BAD_GATEWAY)
```

`str(e)` on a Stripe error can include internal references, request IDs, or card decline reason codes that reveal payment processor internals. Log the full error server-side; return a generic message to the client.

**Fix:**

```python
except stripe.error.StripeError as e:
    logger.error("Stripe error for user %s: %s", request.user.id, str(e))
    return Response({"detail": "Payment processing failed. Please try again."},
                    status=status.HTTP_502_BAD_GATEWAY)
```

---

## 🟡 Medium

### M1 — No GDPR Right to Erasure (Right to Be Forgotten)

**File:** `users/views.py` (AdminUserActionView.delete)

`DELETE /api/admin/users/<id>/` only sets `is_active = False` — it never deletes or anonymises personal data. Under GDPR Article 17, users have the right to have their data erased. The platform collects name, email, phone number, and payment history — all personal data.

**Fix:**  
Implement a `DELETE /api/users/me/` endpoint that:
- Anonymises PII fields (`first_name = "Deleted"`, `last_name = "User"`, `email = f"deleted_{pk}@removed.invalid"`, `phone = ""`)
- Marks the account inactive
- Logs the erasure event with timestamp

Payment records may need to be retained for tax/legal purposes (document this in a privacy policy), but must not retain identifiable user data beyond the retention period.

---

### M2 — No Privacy Policy, Cookie Notice, or Consent Mechanism

**GDPR Articles 13, 14 (information obligations)**

The application collects email, full name, phone number, and payment data from users in Sri Lanka. While Sri Lanka's data protection law is still developing, if any EU residents use the platform, GDPR applies. There is no:
- Privacy policy or data processing disclosure
- Cookie consent banner
- Data retention policy

**Fix:**  
Add a privacy policy page linked from registration. Implement a cookie consent banner if using analytics. Define and document data retention periods.

---

### M3 — `.env.example` Contains a Hard-Coded Insecure `SECRET_KEY`

**File:** `.env.example`

```
SECRET_KEY=django-insecure-super-secret-key-change-this-in-production-2024xai
```

If a developer copies this directly to `.env` and deploys (common), the "insecure" key is the production key. Django's `SECRET_KEY` signs sessions, CSRF tokens, and password reset links — a known key compromises all of these.

**Fix:**  
Replace the example value with a placeholder that cannot be accidentally used:

```
SECRET_KEY=REPLACE_ME_generate_with_python_-c_"from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```

Add a startup check in `settings.py`:

```python
if SECRET_KEY.startswith('django-insecure') and not DEBUG:
    raise RuntimeError("Production SECRET_KEY must not use the insecure default.")
```

---

### M4 — Password Policy Only Enforces Minimum Length

**File:** `users/serializers.py:36–38`, `settings.py`

The custom serializer only checks `len(password) >= 8`. Django's `CommonPasswordValidator` and `NumericPasswordValidator` are configured but the serializer's manual 8-char check runs first. There's no enforcement of complexity (mixed case, digits, symbols) beyond Django's default common-password list.

**Fix:**  
Remove the manual length check and rely solely on Django's validators, or add a stronger regex-based validator. 8 characters with no complexity requirement is weak for an account managing payment data.

---

### M5 — `DEBUG = True` Default in `.env.example`

**File:** `.env.example`

```
DEBUG=True
```

If deployed with `DEBUG=True`, Django returns full stack traces (including local variable values and settings snippets) to any client on an unhandled error. This can expose database credentials, secret keys, or internal paths.

**Fix:**  
Change the example to `DEBUG=False` and add an explicit note that `True` is only for local development.

---

## 🔵 Low / Informational

### L1 — PayPal Integration Uses Deprecated SDK

**File:** `payments/views.py`

`paypalrestsdk` targets the deprecated PayPal REST API v1 (`/v1/payments/`). PayPal has deprecated this in favour of Orders API v2. The SDK also passes LKR amounts with `currency: "USD"` — a discrepancy that will cause PayPal to charge in USD.

**Recommendation:** Migrate to `paypalcheckoutsdk` (or direct HTTP calls to the Orders v2 API) and align currency handling.

---

### L2 — `delete_image_file` Has a No-Op Condition

**File:** `Backend/listings/utils.py:32`

```python
def delete_image_file(image_field):
    if image_field and image_field:   # ← always the same check
        image_field.delete(save=False)
```

The condition `image_field and image_field` evaluates the same reference twice and never checks `image_field.name` (which would be empty string for an unset field). This is a logic bug — not a security issue — but could leave orphaned files on disk.

**Fix:**

```python
def delete_image_file(image_field):
    if image_field and image_field.name:
        image_field.delete(save=False)
```

---

### L3 — Admin Panel Accessible Without MFA

**File:** `Backend/urls.py` (Django admin at `/admin/`)

The Django admin panel has no multi-factor authentication. An admin account compromise (weak password, phishing) gives full database access. Consider `django-otp` or restricting the admin URL to an internal network.

---

## Remediation Priority

| Priority | Issue | Effort |
|---|---|---|
| Immediate | C2 — Logout broken (add blacklist app) | Low — add one line + migrate |
| Immediate | C4 — CORS misconfiguration | Low — 2-line config change |
| Immediate | C1 — Remove `stripe_client_secret` from DB | Medium — migration + code change |
| This sprint | C3 — Move tokens from localStorage to httpOnly cookies | Medium |
| This sprint | H1 — Add login rate throttling | Low |
| This sprint | H2 — Fix ALLOWED_HOSTS + add HTTPS headers | Low |
| This sprint | H4 — Shorten access token lifetime to 15 min | Low |
| Next sprint | H3 — Magic-byte image validation | Low |
| Next sprint | M1 — GDPR right-to-erasure endpoint | Medium |
| Next sprint | M3/M5 — Fix .env.example | Low |
| Backlog | M2 — Privacy policy & consent | Medium |
| Backlog | L1 — PayPal SDK migration | High |
