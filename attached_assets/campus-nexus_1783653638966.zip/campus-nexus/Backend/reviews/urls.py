# ============================================================
#  GIMSARA — reviews/urls.py
# ============================================================

from django.urls import path
from .reviews import ReviewListView, ReviewSummaryView, ReviewCreateView

urlpatterns = [
    path('',         ReviewListView.as_view(),    name='review-list'),
    path('summary/', ReviewSummaryView.as_view(), name='review-summary'),
    path('create/',  ReviewCreateView.as_view(),  name='review-create'),
]