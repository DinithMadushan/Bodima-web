# ============================================================
#  GIMSARA — reviews/reviews.py
#  Serializers + Views — submit, fetch, aggregate
# ============================================================

import calendar
from django.db.models import Avg, Count
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from rest_framework.permissions import IsAuthenticated, AllowAny

from reviews.models import Review


# ── SERIALIZERS ───────────────────────────────────────────────

class ReviewSerializer(serializers.ModelSerializer):
    reviewer_name = serializers.SerializerMethodField()
    reviewer_meta = serializers.SerializerMethodField()
    boarding_name = serializers.SerializerMethodField()

    class Meta:
        model  = Review
        fields = ["id", "reviewer_name", "reviewer_meta", "rating",
                  "boarding_name", "comment", "created_at"]

    def get_reviewer_name(self, obj):
        return obj.student.get_full_name()

    def get_reviewer_meta(self, obj):
        month = calendar.month_name[obj.created_at.month]
        year  = obj.created_at.year
        role_label = "BCI Student" if obj.student.role == "student" else "Owner"
        return f"{role_label} · {month} {year}"

    def get_boarding_name(self, obj):
        return obj.listing.name


class ReviewCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Review
        fields = ["listing", "rating", "comment"]

    def validate_rating(self, value):
        if not 1 <= value <= 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


# ── VIEWS ─────────────────────────────────────────────────────

class ReviewListView(APIView):
    """
    GET /api/reviews/
    Query params:
      listing_id → filter by listing
      rating     → filter by star rating
    """
    permission_classes = [AllowAny]

    def get(self, request):
        qs = Review.objects.select_related(
            "student", "listing"
        ).order_by("-created_at")

        listing_id = request.query_params.get("listing_id")
        rating     = request.query_params.get("rating")

        if listing_id:
            qs = qs.filter(listing_id=listing_id)
        if rating:
            qs = qs.filter(rating=int(rating))

        serializer = ReviewSerializer(qs, many=True)
        return Response(serializer.data)


class ReviewSummaryView(APIView):
    """
    GET /api/reviews/summary/?listing_id=
    Returns avg rating, total count, breakdown per star
    """
    permission_classes = [AllowAny]

    def get(self, request):
        qs = Review.objects.all()
        listing_id = request.query_params.get("listing_id")
        if listing_id:
            qs = qs.filter(listing_id=listing_id)

        agg = qs.aggregate(avg=Avg("rating"), total=Count("id"))
        breakdown = {}
        for star in range(1, 6):
            breakdown[str(star)] = qs.filter(rating=star).count()

        return Response({
            "avg_rating": round(agg["avg"] or 0, 1),
            "total":      agg["total"],
            "breakdown":  breakdown,
        })


class ReviewCreateView(APIView):
    """
    POST /api/reviews/create/
    Body: { "listing": <id>, "rating": 4, "comment": "Great place!" }
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if request.user.role != "student":
            return Response(
                {"detail": "Only students can write reviews."},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = ReviewCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        listing = serializer.validated_data["listing"]
        if Review.objects.filter(
            listing=listing, student=request.user
        ).exists():
            return Response(
                {"detail": "You have already reviewed this listing."},
                status=status.HTTP_400_BAD_REQUEST
            )

        review = serializer.save(student=request.user)

        # Update cached rating on listing
        agg = Review.objects.filter(listing=listing).aggregate(
            avg=Avg("rating"), cnt=Count("id")
        )
        listing.rating  = round(agg["avg"] or 0, 1)
        listing.reviews = agg["cnt"]
        listing.save(update_fields=["rating", "reviews"])

        return Response(
            ReviewSerializer(review).data,
            status=status.HTTP_201_CREATED
        )