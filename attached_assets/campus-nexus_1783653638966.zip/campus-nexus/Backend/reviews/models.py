# ============================================================
#  GIMSARA — reviews/models.py
#  Review model — moved here so Django migrations can detect it
# ============================================================

from django.db import models
from users.models import User
from listings.models import Listing


class Review(models.Model):
    listing    = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="listing_reviews")
    student    = models.ForeignKey(User, on_delete=models.CASCADE, related_name="reviews_written")
    rating     = models.PositiveSmallIntegerField()      # 1–5 stars
    comment    = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "reviews"
        # One review per student per listing
        unique_together = [("listing", "student")]

    def __str__(self):
        return f"{self.student.get_full_name()} → {self.listing.name} ({self.rating}★)"
