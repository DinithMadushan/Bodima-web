# ============================================================
#  DINITH — tests/test_dinith.py
#  Unit tests for:
#    - Auth API         (RegisterView, LoginView, LogoutView)
#    - Listings API     (ListingSearchView, ListingFeaturedView,
#                        ListingDetailView)
#    - Admin API        (AdminListingListView, AdminListingApproveView)
# ============================================================

from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status

from users.models import User
from listings.models import Listing


# ── HELPERS ───────────────────────────────────────────────────

def make_student(email="student@test.com", password="pass1234"):
    return User.objects.create_user(
        email=email, password=password,
        first_name="Test", last_name="Student", role="student"
    )

def make_owner(email="owner@test.com", password="pass1234"):
    return User.objects.create_user(
        email=email, password=password,
        first_name="Test", last_name="Owner", role="owner"
    )

def make_admin(email="admin@test.com", password="pass1234"):
    return User.objects.create_superuser(
        email=email, password=password,
        first_name="Admin", last_name="User"
    )

def make_listing(owner, status=Listing.STATUS_APPROVED, **kwargs):
    defaults = dict(
        name="Sunny Room", area="Kuruna, Negombo",
        location="Negombo", price=8000,
        type=Listing.TYPE_SINGLE, gender=Listing.GENDER_MIXED,
        desc="Nice place.", badge="Popular"
    )
    defaults.update(kwargs)
    return Listing.objects.create(owner=owner, status=status, **defaults)


# ── AUTH TESTS ────────────────────────────────────────────────

class RegisterViewTest(TestCase):

    def setUp(self):
        self.client = APIClient()

    def test_student_can_register(self):
        res = self.client.post("/api/auth/register/", {
            "email": "new@test.com",
            "password": "pass1234",
            "first_name": "New",
            "last_name": "User",
            "role": "student"
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertTrue(User.objects.filter(email="new@test.com").exists())

    def test_owner_can_register(self):
        res = self.client.post("/api/auth/register/", {
            "email": "owner@test.com",
            "password": "pass1234",
            "first_name": "Owner",
            "last_name": "User",
            "role": "owner"
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)

    def test_duplicate_email_rejected(self):
        make_student("dup@test.com")
        res = self.client.post("/api/auth/register/", {
            "email": "dup@test.com",
            "password": "pass1234",
            "first_name": "Dup",
            "last_name": "User",
            "role": "student"
        })
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_missing_fields_rejected(self):
        res = self.client.post("/api/auth/register/", {
            "email": "incomplete@test.com"
        })
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)


class LoginViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.student = make_student()

    def test_valid_login_returns_tokens(self):
        res = self.client.post("/api/auth/login/", {
            "email": "student@test.com",
            "password": "pass1234"
        })
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn("access", res.data)
        self.assertIn("refresh", res.data)
        self.assertIn("role", res.data)
        self.assertIn("full_name", res.data)

    def test_wrong_password_rejected(self):
        res = self.client.post("/api/auth/login/", {
            "email": "student@test.com",
            "password": "wrongpass"
        })
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_nonexistent_email_rejected(self):
        res = self.client.post("/api/auth/login/", {
            "email": "ghost@test.com",
            "password": "pass1234"
        })
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_login_returns_correct_role(self):
        res = self.client.post("/api/auth/login/", {
            "email": "student@test.com",
            "password": "pass1234"
        })
        self.assertEqual(res.data["role"], "student")


class LogoutViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.student = make_student()

    def _get_tokens(self):
        res = self.client.post("/api/auth/login/", {
            "email": "student@test.com",
            "password": "pass1234"
        })
        return res.data["access"], res.data["refresh"]

    def test_logout_blacklists_refresh_token(self):
        access, refresh = self._get_tokens()
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {access}")
        res = self.client.post("/api/auth/logout/", {"refresh": refresh})
        self.assertEqual(res.status_code, status.HTTP_200_OK)

    def test_logout_without_refresh_token_rejected(self):
        access, _ = self._get_tokens()
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {access}")
        res = self.client.post("/api/auth/logout/", {})
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_unauthenticated_cannot_logout(self):
        res = self.client.post("/api/auth/logout/", {"refresh": "fake"})
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)


# ── LISTING SEARCH TESTS ──────────────────────────────────────

class ListingSearchViewTest(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.owner  = make_owner()
        make_listing(self.owner, name="Beach Room",
                     location="Negombo", price=7000,
                     type=Listing.TYPE_SINGLE, gender=Listing.GENDER_MALE)
        make_listing(self.owner, name="City Annex",
                     location="Wattala", price=12000,
                     type=Listing.TYPE_ANNEX, gender=Listing.GENDER_FEMALE)
        # pending — should NOT appear in search
        make_listing(self.owner, status=Listing.STATUS_PENDING,
                     name="Hidden Room", location="Negombo", price=5000)

    def test_returns_only_approved_listings(self):
        res = self.client.get("/api/listings/search/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 2)

    def test_filter_by_location(self):
        res = self.client.get("/api/listings/search/?location=Negombo")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)
        self.assertEqual(res.data[0]["name"], "Beach Room")

    def test_filter_by_min_price(self):
        res = self.client.get("/api/listings/search/?min_price=10000")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)
        self.assertEqual(res.data[0]["name"], "City Annex")

    def test_filter_by_max_price(self):
        res = self.client.get("/api/listings/search/?max_price=8000")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_filter_by_type(self):
        res = self.client.get("/api/listings/search/?type=Annex")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)
        self.assertEqual(res.data[0]["name"], "City Annex")

    def test_filter_by_gender(self):
        res = self.client.get("/api/listings/search/?gender=Female Only")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_text_search_by_name(self):
        res = self.client.get("/api/listings/search/?q=Beach")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_sort_by_price_asc(self):
        res = self.client.get("/api/listings/search/?sort=price_asc")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        prices = [r["price"] for r in res.data]
        self.assertEqual(prices, sorted(prices))

    def test_sort_by_price_desc(self):
        res = self.client.get("/api/listings/search/?sort=price_desc")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        prices = [r["price"] for r in res.data]
        self.assertEqual(prices, sorted(prices, reverse=True))

    def test_no_auth_required(self):
        res = self.client.get("/api/listings/search/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)


# ── LISTING FEATURED TESTS ────────────────────────────────────

class ListingFeaturedViewTest(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.owner  = make_owner()
        make_listing(self.owner, badge="Popular")
        make_listing(self.owner, badge="Popular", name="Room 2",
                     email="o2@test.com" if False else None)
        make_listing(self.owner, badge="", name="No Badge Room")
        make_listing(self.owner, status=Listing.STATUS_PENDING,
                     badge="Popular", name="Pending Featured")

    def test_returns_only_approved_featured(self):
        res = self.client.get("/api/listings/featured/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        for item in res.data:
            self.assertTrue(item.get("badge"))

    def test_no_auth_required(self):
        res = self.client.get("/api/listings/featured/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)


# ── LISTING DETAIL TESTS ──────────────────────────────────────

class ListingDetailViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.listing = make_listing(self.owner)

    def test_get_existing_listing(self):
        res = self.client.get(f"/api/listings/{self.listing.id}/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data["name"], "Sunny Room")

    def test_get_nonexistent_listing_returns_404(self):
        res = self.client.get("/api/listings/99999/")
        self.assertEqual(res.status_code, status.HTTP_404_NOT_FOUND)

    def test_no_auth_required(self):
        res = self.client.get(f"/api/listings/{self.listing.id}/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)


# ── ADMIN LISTING TESTS ───────────────────────────────────────

class AdminListingListViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.admin   = make_admin()
        self.owner   = make_owner()
        self.student = make_student()
        make_listing(self.owner, status=Listing.STATUS_PENDING)
        make_listing(self.owner, status=Listing.STATUS_APPROVED, name="Room 2")

    def test_admin_can_list_all_listings(self):
        self.client.force_authenticate(self.admin)
        res = self.client.get("/api/admin/listings/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 2)

    def test_student_cannot_access_admin_listings(self):
        self.client.force_authenticate(self.student)
        res = self.client.get("/api/admin/listings/")
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_owner_cannot_access_admin_listings(self):
        self.client.force_authenticate(self.owner)
        res = self.client.get("/api/admin/listings/")
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_unauthenticated_cannot_access_admin_listings(self):
        res = self.client.get("/api/admin/listings/")
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)


class AdminListingApproveViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.admin   = make_admin()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner, status=Listing.STATUS_PENDING)

    def test_admin_can_approve_listing(self):
        self.client.force_authenticate(self.admin)
        res = self.client.patch(
            f"/api/admin/listings/{self.listing.id}/",
            {"status": "approved"}
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.listing.refresh_from_db()
        self.assertEqual(self.listing.status, Listing.STATUS_APPROVED)

    def test_admin_can_reject_listing(self):
        self.client.force_authenticate(self.admin)
        res = self.client.patch(
            f"/api/admin/listings/{self.listing.id}/",
            {"status": "rejected"}
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.listing.refresh_from_db()
        self.assertEqual(self.listing.status, Listing.STATUS_REJECTED)

    def test_student_cannot_approve_listing(self):
        self.client.force_authenticate(self.student)
        res = self.client.patch(
            f"/api/admin/listings/{self.listing.id}/",
            {"status": "approved"}
        )
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_invalid_status_rejected(self):
        self.client.force_authenticate(self.admin)
        res = self.client.patch(
            f"/api/admin/listings/{self.listing.id}/",
            {"status": "maybe"}
        )
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)