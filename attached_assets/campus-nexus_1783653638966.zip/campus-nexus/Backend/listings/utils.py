from django.core.exceptions import ValidationError
from PIL import Image
from django.conf import settings
from io import BytesIO


def validate_image_file(file_obj, max_size_mb=5):
    """
    Validate uploaded image file.
    - Type: jpg, jpeg, png, webp
    - Size: max 5MB
    Raises ValidationError if invalid.
    """
    allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
    if file_obj.content_type not in allowed_types:
        raise ValidationError('Unsupported file type. Allowed: JPEG, PNG, WebP.')

    if file_obj.size > max_size_mb * 1024 * 1024:
        raise ValidationError(f'File too large. Max size: {max_size_mb}MB.')

    # Verify it's a real image
    try:
        img = Image.open(file_obj)
        img.verify()
    except:
        raise ValidationError('Invalid image file.')


def delete_image_file(image_field):
    """
    Safely delete image file from disk.
    Call before obj.save() or in pre_delete signal.
    """
    if image_field and image_field:
        image_field.delete(save=False)


def get_absolute_image_url(request, image_field):
    """
    Return absolute URL for image field.
    """
    if image_field and hasattr(image_field, 'url'):
        return request.build_absolute_uri(image_field.url)
    return None

