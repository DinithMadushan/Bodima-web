# ============================================================
#  DINITH — listings/serializers.py
# ============================================================

from rest_framework import serializers
from .models import Listing, ListingImage
from .utils import get_absolute_image_url


class ListingImageSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = ListingImage
        fields = ['id', 'image_url', 'caption', 'is_primary', 'uploaded_at']

    def get_image_url(self, obj):
        request = self.context.get('request')
        return get_absolute_image_url(request, obj.image)


class ListingSerializer(serializers.ModelSerializer):
    amenities     = serializers.SerializerMethodField()
    thumbnail_url = serializers.SerializerMethodField()
    images        = ListingImageSerializer(source='images', many=True, read_only=True)

    class Meta:
        model  = Listing
        fields = ["id", "name", "area", "price", "rating", "reviews",
                  "badge", "img", "amenities", "desc", "thumbnail_url", "images"]

    def get_amenities(self, obj):
        return obj.get_amenities_list()

    def get_thumbnail_url(self, obj):
        request = self.context.get('request')
        return get_absolute_image_url(request, obj.thumbnail)


class ListingDetailSerializer(serializers.ModelSerializer):
    amenities     = serializers.SerializerMethodField()
    thumbnail_url = serializers.SerializerMethodField()
    images        = ListingImageSerializer(many=True, read_only=True)
    owner_name    = serializers.SerializerMethodField()
    owner_since   = serializers.SerializerMethodField()
    map_embed_url = serializers.SerializerMethodField()

    class Meta:
        model  = Listing
        fields = [
            "id", "name", "area", "location", "price", "rating", "reviews",
            "badge", "img", "amenities", "desc", "images",
            "type", "deposit_months", "meals_included", "wifi_included", "available_from",
            "owner_name", "owner_since",
            "latitude", "longitude", "map_embed_url", "thumbnail_url",
        ]

    def get_amenities(self, obj):
        return obj.get_amenities_list()

    def get_thumbnail_url(self, obj):
        request = self.context.get('request')
        return get_absolute_image_url(request, obj.thumbnail)

    def get_owner_name(self, obj):
        return obj.owner.get_full_name()

    def get_owner_since(self, obj):
        return obj.owner.created_at.year

    def get_map_embed_url(self, obj):
        if obj.latitude and obj.longitude:
            return (
                f"https://www.google.com/maps/embed/v1/place"
                f"?key=YOUR_GOOGLE_MAPS_API_KEY"
                f"&q={obj.latitude},{obj.longitude}&zoom=15"
            )
        return None


class ListingCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Listing
        fields = [
            "name", "area", "location", "price", "type", "gender",
            "desc", "amenities", "deposit_months", "meals_included",
            "wifi_included", "available_from", "img", "latitude", "longitude",
        ]