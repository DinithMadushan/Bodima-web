# ============================================================
#  DINITH — listings/views.py
#  Search, Featured, Detail, Admin Approve/Reject
#
#  Wires up:
#    search.html  — fetch replaces hardcoded JS listings[] array
#    home.html    — 3 featured property cards
#    details.html — full listing detail page
#    Admin dashboard — approve / reject listings
# ============================================================

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.db import transaction
from django_filters.rest_framework import DjangoFilterBackend
from django.core.exceptions import ValidationError
from .permissions import IsOwnerOrAdmin
from .models import Listing, ListingImage
from .serializers import ListingSerializer, ListingDetailSerializer, ListingCreateSerializer, ListingImageSerializer
from .utils import validate_image_file


from django.db.models import Q
from django.core.cache import cache
import hashlib
import json

class ListingSearchView(APIView):
    """
    GET /api/listings/

    Query params — each maps directly to Thamshi's search.html filter controls:
      q          → text search input (searches name + area)
      location   → location dropdown (Negombo / Ja-Ela / Wattala / Gampaha)
      min_price  → #minPrice slider value
      max_price  → #maxPrice slider value
      type       → type dropdown (Single Room / Shared Room / Annex)
      gender     → gender checkboxes (Male Only / Female Only / Mixed)
      amenities  → comma-separated amenity names from .checkbox-group checkboxes
      sort       → sort-select value (price_asc / price_desc / rating / newest)

    Response: JSON array matching the JS listings[] object shape exactly:
      [{ id, name, area, price, rating, reviews, badge, img, amenities, desc }, ...]
    """
    permission_classes = [AllowAny]

    CACHE_TTL = 60  # seconds

    def _build_cache_key(self, params):
        raw = json.dumps(dict(params), sort_keys=True)
        return "search:" + hashlib.md5(raw.encode()).hexdigest()

    def get(self, request):
        params = request.query_params

        # --- Cache check ---
        cache_key = self._build_cache_key(params)
        cached = cache.get(cache_key)
        if cached is not None:
            return Response(cached)

        # --- Base queryset: only fetch columns the serializer needs ---
        qs = (
            Listing.objects
            .filter(status=Listing.STATUS_APPROVED)
            .only(
                "id", "name", "area", "price", "rating",
                "reviews", "badge", "img", "amenities", "desc",
            )
        )

        q         = params.get("q")
        location  = params.get("location")
        min_price = params.get("min_price")
        max_price = params.get("max_price")
        room_type = params.get("type")
        gender    = params.get("gender")
        amenities = params.get("amenities")
        sort      = params.get("sort", "newest")

        if q:
            qs = qs.filter(Q(name__icontains=q) | Q(area__icontains=q))
        if location:
            qs = qs.filter(location=location)
        if min_price:
            qs = qs.filter(price__gte=int(min_price))
        if max_price:
            qs = qs.filter(price__lte=int(max_price))
        if room_type:
            qs = qs.filter(type=room_type)
        if gender:
            qs = qs.filter(gender=gender)
        if amenities:
            for amenity in amenities.split(","):
                qs = qs.filter(amenities__icontains=amenity.strip())

        sort_map = {
            "price_asc":  "price",
            "price_desc": "-price",
            "rating":     "-rating",
            "newest":     "-created_at",
        }
        qs = qs.order_by(sort_map.get(sort, "-created_at"))

        serializer = ListingSerializer(qs, many=True)
        data = serializer.data

        # --- Store in cache ---
        cache.set(cache_key, data, self.CACHE_TTL)

        return Response(data)


class ListingFeaturedView(APIView):
    """
    GET /api/listings/featured/
    Returns 3 approved featured listings for home.html property cards.
    """
    permission_classes = [AllowAny]

    def get(self, request):
        qs = Listing.objects.filter(
            status=Listing.STATUS_APPROVED,
            badge__isnull=False
        ).order_by("-rating")[:3]
        serializer = ListingSerializer(qs, many=True)
        return Response(serializer.data)


class ListingDetailView(APIView):
    """
    GET /api/listings/<id>/

    Returns full listing data for details.html.
    Includes booking-card fields: type, deposit_months, meals_included,
    wifi_included, available_from, owner info, images, lat, lng.
    """
    permission_classes = [AllowAny]

    def get(self, request, pk):
        try:
            listing = Listing.objects.select_related("owner").get(
                pk=pk, status=Listing.STATUS_APPROVED
            )
        except Listing.DoesNotExist:
            return Response({"detail": "Listing not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = ListingDetailSerializer(listing)
        return Response(serializer.data)


class AdminListingApproveView(APIView):
    """
    PATCH /api/admin/listings/<id>/

    Admin only. Body: { "status": "approved" } or { "status": "rejected" }
    Used by admin dashboard approve/reject buttons.
    """
    permission_classes = [IsAdminUser]

    def patch(self, request, pk):
        try:
            listing = Listing.objects.get(pk=pk)
        except Listing.DoesNotExist:
            return Response({"detail": "Listing not found."}, status=status.HTTP_404_NOT_FOUND)

        new_status = request.data.get("status")
        if new_status not in [Listing.STATUS_APPROVED, Listing.STATUS_REJECTED]:
            return Response(
                {"status": "Must be 'approved' or 'rejected'."},
                status=status.HTTP_400_BAD_REQUEST
            )

        listing.status = new_status
        listing.save(update_fields=["status"])
        return Response({"id": listing.id, "status": listing.status})


class AdminListingListView(APIView):
    """
    GET /api/admin/listings/
    Returns all pending listings for the admin dashboard table.
    """
    permission_classes = [IsAdminUser]

    def get(self, request):
        qs = Listing.objects.filter(status=Listing.STATUS_PENDING).order_by("created_at")
        serializer = ListingSerializer(qs, many=True)
        return Response(serializer.data)


# NEW: Full CRUD operations for listings with image support
class ListingListCreateView(ListCreateAPIView):
    permission_classes = [IsOwnerOrAdmin]
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['location', 'type', 'gender', 'price__gte', 'price__lte']

    def get_queryset(self):
        return Listing.objects.filter(status=Listing.STATUS_APPROVED).select_related('owner').prefetch_related('images').order_by('-created_at')

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ListingCreateSerializer
        return ListingSerializer

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user, status=Listing.STATUS_PENDING)


class ListingRetrieveUpdateDestroyView(RetrieveUpdateDestroyAPIView):
    queryset = Listing.objects.select_related('owner').prefetch_related('images').all()
    serializer_class = ListingDetailSerializer
    permission_classes = [IsOwnerOrAdmin]


class ListingImageListCreateView(APIView):
    permission_classes = [IsOwnerOrAdmin]

    def get(self, request, listing_pk):
        images = ListingImage.objects.filter(listing_id=listing_pk).order_by('-is_primary', '-uploaded_at')
        serializer = ListingImageSerializer(images, many=True, context={'request': request})
        return Response(serializer.data)

    @transaction.atomic
    def post(self, request, listing_pk):
        listing = get_object_or_404(Listing, pk=listing_pk)
        if not IsOwnerOrAdmin.has_object_permission(request, None, listing):
            return Response({'error': 'Permission denied.'}, status=status.HTTP_403_FORBIDDEN)

        files = request.FILES.getlist('images')
        if not files:
            return Response({'error': 'No images provided.'}, status=status.HTTP_400_BAD_REQUEST)

        if len(files) > 10:
            return Response({'error': 'Maximum 10 images per listing.'}, status=status.HTTP_400_BAD_REQUEST)

        uploaded = []
        captions = request.data.getlist('captions') if 'captions' in request.data else [''] * len(files)
        for file_obj, caption in zip(files, captions[:len(files)]):
            try:
                validate_image_file(file_obj)
                serializer = ListingImageSerializer(data={
                    'image': file_obj,
                    'caption': caption[:200],
                    'listing': listing_pk
                }, context={'request': request})
                if serializer.is_valid():
                    img = serializer.save()
                    uploaded.append(serializer.data)
            except Exception as e:
                return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'uploaded': len(uploaded),
            'images': uploaded
        }, status=status.HTTP_201_CREATED)


class ListingImageRetrieveUpdateDestroyView(RetrieveUpdateDestroyAPIView):
    serializer_class = ListingImageSerializer
    permission_classes = [IsOwnerOrAdmin]
    lookup_url_kwarg = 'image_pk'

    def get_queryset(self):
        return ListingImage.objects.filter(listing_id=self.kwargs['listing_pk'])

    def perform_destroy(self, instance):
        # Extra cleanup if needed
        super().perform_destroy(instance)


class ListingImageSetPrimaryView(APIView):
    permission_classes = [IsOwnerOrAdmin]

    def patch(self, request, listing_pk, image_pk):
        img = get_object_or_404(ListingImage, pk=image_pk, listing_id=listing_pk)
        if not IsOwnerOrAdmin.has_object_permission(request, None, img.listing):
            return Response({'error': 'Permission denied.'}, status=status.HTTP_403_FORBIDDEN)

        # Unset other primary images
        ListingImage.objects.filter(
            listing_id=listing_pk, is_primary=True
        ).update(is_primary=False)

        img.is_primary = True
        img.save(update_fields=['is_primary'])

        serializer = ListingImageSerializer(img, context={'request': request})
        return Response({
            'message': 'Image set as primary successfully',
            'image_id': img.id,
            'image': serializer.data
        })

