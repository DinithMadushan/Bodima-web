# ============================================================
#  DINITH — listings/models.py
#  Boarding listing model
#
#  Field names chosen to match Thamshi's search.html JS array:
#    { id, name, area, price, rating, reviews, badge, img, amenities, desc }
#  and details.html booking-card:
#    Room Type, Deposit, Meals, WiFi, Available From
# ============================================================

from django.db import models
from users.models import User


class Listing(models.Model):
    STATUS_PENDING  = "pending"
    STATUS_APPROVED = "approved"
    STATUS_REJECTED = "rejected"
    STATUS_CHOICES  = [
        (STATUS_PENDING,  "Pending Approval"),
        (STATUS_APPROVED, "Approved"),
        (STATUS_REJECTED, "Rejected"),
    ]

    TYPE_SINGLE = "Single Room"
    TYPE_SHARED = "Shared Room"
    TYPE_ANNEX  = "Annex"
    TYPE_CHOICES = [
        (TYPE_SINGLE, "Single Room"),
        (TYPE_SHARED, "Shared Room"),
        (TYPE_ANNEX,  "Annex"),
    ]

    GENDER_MALE   = "Male Only"
    GENDER_FEMALE = "Female Only"
    GENDER_MIXED  = "Mixed"
    GENDER_CHOICES = [
        (GENDER_MALE,   "Male Only"),
        (GENDER_FEMALE, "Female Only"),
        (GENDER_MIXED,  "Mixed"),
    ]

    # Core fields (match search.html JS object keys)
    name        = models.CharField(max_length=200)          # JS: name
    area        = models.CharField(max_length=200)          # JS: area  e.g. "Kuruna, Negombo"
    location    = models.CharField(max_length=100)          # dropdown: Negombo/Ja-Ela/Wattala/Gampaha
    price       = models.PositiveIntegerField()             # JS: price (Rs per month)
    type        = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_SINGLE)
    gender      = models.CharField(max_length=15, choices=GENDER_CHOICES, default=GENDER_MIXED)
    desc        = models.TextField()                        # JS: desc
    badge       = models.CharField(max_length=50, blank=True, null=True) # JS: badge ("Featured", "Hot Deal" etc.)

    # details.html booking-card fields
    deposit_months  = models.PositiveSmallIntegerField(default=2)
    meals_included  = models.BooleanField(default=False)
    wifi_included   = models.BooleanField(default=False)
    available_from  = models.CharField(max_length=100, default="Immediately")

    # Amenities stored as comma-separated string matching Thamshi's format
    # e.g. "📶 WiFi,🍽 Meals,🚿 Bath"  — JS splits on comma for amenity chips
    amenities   = models.TextField(blank=True, default="")

    # Map location
    latitude    = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude   = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)

    # Primary image URL (JS: img)
    img         = models.URLField(blank=True)

    # Thumbnail for list view
    thumbnail   = models.ImageField(upload_to='listings/thumbnails/', null=True, blank=True)

    # Computed rating fields (updated when a new review is saved)
    rating      = models.DecimalField(max_digits=3, decimal_places=1, default=0.0)  # JS: rating
    reviews     = models.PositiveIntegerField(default=0)                            # JS: reviews

    owner       = models.ForeignKey(User, on_delete=models.CASCADE, related_name="listings")
    status      = models.CharField(max_length=10, choices=STATUS_CHOICES, default=STATUS_PENDING)
    created_at  = models.DateTimeField(auto_now_add=True)

class Meta:
    db_table = "listings"
    indexes = [
        models.Index(fields=["status", "location"]),
        models.Index(fields=["status", "price"]),
        models.Index(fields=["status", "type"]),
        models.Index(fields=["status", "gender"]),
        models.Index(fields=["status", "-created_at"]),
        models.Index(fields=["status", "-rating"]),
    ]

    def get_amenities_list(self):
        """Return amenities as Python list for the JS array in search results."""
        return [a.strip() for a in self.amenities.split(",") if a.strip()]

    def __str__(self):
        return self.name

from django.db.models.signals import pre_save, pre_delete
from django.dispatch import receiver
from . import utils

@receiver(pre_delete, sender=ListingImage)
def auto_delete_file_on_listingimage_delete(sender, instance, **kwargs):
    """Deletes file from filesystem when ListingImage deleted."""
    if instance.image:
        utils.delete_image_file(instance.image)

@receiver(pre_save, sender=ListingImage)
def auto_delete_file_on_listingimage_update(sender, instance, **kwargs):
    """Deletes old file from filesystem when ListingImage updated."""
    if not instance.pk:
        return False

    try:
        old_instance = sender.objects.get(pk=instance.pk)
        if old_instance.image != instance.image:
            utils.delete_image_file(old_instance.image)
    except sender.DoesNotExist:
        return False

@receiver(pre_delete, sender=Listing)
def auto_delete_thumbnail_on_listing_delete(sender, instance, **kwargs):
    """Deletes thumbnail from filesystem when Listing deleted."""
    if instance.thumbnail:
        utils.delete_image_file(instance.thumbnail)



class ListingImage(models.Model):
    """Extra images for the gallery with upload support."""
    listing     = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="images")
    image       = models.ImageField(upload_to="listings/images/")
    caption     = models.CharField(max_length=200, blank=True)
    is_primary  = models.BooleanField(default=False)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.listing.name} - Image {self.id}"

    class Meta:
        db_table = "listing_images"
        ordering = ['-is_primary', '-uploaded_at']
