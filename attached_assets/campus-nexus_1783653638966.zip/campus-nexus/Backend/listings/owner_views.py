# ============================================================
#  GIMSARA — listings/owner_views.py
#  Owner: Create, Edit, Delete listings + Upload images
#
#  Wires up:
#    Owner dashboard — add listing form
#    Owner dashboard — edit listing form
#    Owner dashboard — delete listing button
#    Owner dashboard — photo upload
# ============================================================

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, BasePermission

from listings.models import Listing, ListingImage
from listings.serializers import ListingCreateSerializer, ListingSerializer, ListingImageSerializer
from listings.utils import validate_image_file
from django.shortcuts import get_object_or_404
from django.db import transaction


class IsOwner(BasePermission):
    """Custom permission — only owners or admins can access owner endpoints."""
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ("owner", "admin")


class OwnerListingView(APIView):
    """
    GET  /api/owner/listings/       → owner's own listings
    POST /api/owner/listings/       → create new listing (status=pending by default)

    POST body matches owner dashboard add listing form:
        name, area, location, price, type, gender, desc, amenities,
        deposit_months, meals_included, wifi_included, available_from, img
    """
    permission_classes = [IsOwner]

    def get(self, request):
        listings = Listing.objects.filter(owner=request.user).order_by("-created_at")
        serializer = ListingSerializer(listings, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ListingCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # status defaults to "pending" — admin must approve before it appears in search
        listing = serializer.save(owner=request.user, status=Listing.STATUS_PENDING)
        return Response(
            {"id": listing.id, "detail": "Listing submitted for approval."},
            status=status.HTTP_201_CREATED
        )


class OwnerListingEditView(APIView):
    """
    PUT    /api/owner/listings/<id>/   → edit own listing
    DELETE /api/owner/listings/<id>/   → delete own listing

    Owner can only edit/delete listings they own.
    """
    permission_classes = [IsOwner]

    def _get_own_listing(self, request, pk):
        try:
            return Listing.objects.get(pk=pk, owner=request.user)
        except Listing.DoesNotExist:
            return None

    def put(self, request, pk):
        listing = self._get_own_listing(request, pk)
        if not listing:
            return Response({"detail": "Listing not found or not yours."}, status=status.HTTP_404_NOT_FOUND)

        serializer = ListingCreateSerializer(listing, data=request.data, partial=True)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Editing resets status to pending — needs re-approval
        serializer.save(status=Listing.STATUS_PENDING)
        return Response({"detail": "Listing updated. Awaiting re-approval."})

    def delete(self, request, pk):
        listing = self._get_own_listing(request, pk)
        if not listing:
            return Response({"detail": "Listing not found or not yours."}, status=status.HTTP_404_NOT_FOUND)

        listing.delete()
        return Response({"detail": "Listing deleted."}, status=status.HTTP_204_NO_CONTENT)


class ListingImageUploadView(APIView):
    """
    POST /api/owner/listings/<id>/images/
    Bulk file upload for owner dashboard.
    Multipart: images[] files, optional captions[] list.
    """
    permission_classes = [IsOwner]

    @transaction.atomic
    def post(self, request, pk):
        try:
            listing = Listing.objects.get(pk=pk, owner=request.user)
        except Listing.DoesNotExist:
            return Response({"detail": "Listing not found or not yours."}, status=status.HTTP_404_NOT_FOUND)

        files = request.FILES.getlist('images')
        if not files:
            return Response({"detail": "No images provided."}, status=status.HTTP_400_BAD_REQUEST)

        if len(files) > 10:
            return Response({"detail": "Maximum 10 images."}, status=status.HTTP_400_BAD_REQUEST)

        uploaded = []
        captions = request.data.getlist('captions', [''] * len(files))
        for file_obj, caption in zip(files, captions):
            try:
                validate_image_file(file_obj)
                img = ListingImage.objects.create(
                    listing=listing,
                    image=file_obj,
                    caption=caption[:200]
                )
                serializer = ListingImageSerializer(img, context={'request': request})
                uploaded.append(serializer.data)
            except Exception as e:
                return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            "uploaded": len(uploaded),
            "images": uploaded
        }, status=status.HTTP_201_CREATED)
