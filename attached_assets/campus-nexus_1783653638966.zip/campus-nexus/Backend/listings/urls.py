"""
listings app URLs for CRUD + images.
To be included as path('api/listings/', include('listings.urls'))
"""

from django.urls import path
from . import views  # public views

urlpatterns = [
    # Listing CRUD
    path('', views.ListingListCreateView.as_view(), name='listing-list-create'),
    path('<int:pk>/', views.ListingRetrieveUpdateDestroyView.as_view(), name='listing-detail'),

    # Listing images
    path('<int:listing_pk>/images/', views.ListingImageListCreateView.as_view(), name='listing-images-list-create'),
    path('<int:listing_pk>/images/<int:image_pk>/', views.ListingImageRetrieveUpdateDestroyView.as_view(), name='listing-image-detail'),
    path('<int:listing_pk>/images/<int:image_pk>/primary/', views.ListingImageSetPrimaryView.as_view(), name='listing-image-set-primary'),
]

