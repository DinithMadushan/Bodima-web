from rest_framework.permissions import BasePermission
from rest_framework import permissions


class IsOwnerOrAdmin(BasePermission):
    """
    Custom permission for listing endpoints.
    Allows:
    - Public GET (AllowAny)
    - Owner/Admin for POST/PUT/PATCH/DELETE/images
    Object-level: request.user == obj.owner or request.user.role == 'admin'
    """
    def has_permission(self, request, view):
        # For list/create/images list: authenticated owner/admin
        if request.method in permissions.SAFE_METHODS:
            return True  # Public read handled by view perms
        return request.user and request.user.is_authenticated and request.user.role in ['owner', 'admin']

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return request.user == obj.owner or (hasattr(request.user, 'role') and request.user.role == 'admin')

