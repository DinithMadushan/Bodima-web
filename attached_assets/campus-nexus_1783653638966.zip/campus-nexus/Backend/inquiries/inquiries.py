# ============================================================
#  GIMSARA — inquiries/inquiries.py
#  Serializers + Views for student → owner messaging
#
#  Wires up:
#    details.html  "💬 Message Owner" button (btn-contact class)
#    details.html  "📞 Request to Visit" button (btn-book class)
#    Owner dashboard inbox
# ============================================================

##from urllib import request

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from rest_framework.permissions import IsAuthenticated

from inquiries.models import Inquiry


# ── SERIALIZERS ───────────────────────────────────────────────────────────────

class InquiryCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Inquiry
        fields = ["listing", "message", "type"]


class InquiryReadSerializer(serializers.ModelSerializer):
    """For owner's inbox — shows who sent the message and for which listing."""
    student_name  = serializers.SerializerMethodField()
    student_email = serializers.SerializerMethodField()
    listing_name  = serializers.SerializerMethodField()

    class Meta:
        model  = Inquiry
        fields = ["id", "student_name", "student_email", "listing_name",
                  "message", "type", "is_read", "created_at"]

    def get_student_name(self, obj):
        return obj.student.get_full_name()

    def get_student_email(self, obj):
        return obj.student.email

    def get_listing_name(self, obj):
        return obj.listing.name


# ── VIEWS ─────────────────────────────────────────────────────────────────────

class InquiryCreateView(APIView):
    """
    POST /api/inquiries/

    Auth required — student must be logged in.
    Wires up details.html:
      "💬 Message Owner"   → type: "message"
      "📞 Request to Visit" → type: "visit"

    Body: { "listing": <id>, "message": "Is the room still available?", "type": "message" }
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if request.user.role != "student":
            return Response(
                {"detail": "Only students can send inquiries."},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = InquiryCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        inquiry = serializer.save(student=request.user)
        return Response(
            {"detail": "Message sent to owner.", "id": inquiry.id},
            status=status.HTTP_201_CREATED
        )


class OwnerInboxView(APIView):
    permission_classes = [IsAuthenticated]

    def _check_owner(self, request):
        if request.user.role not in ("owner", "admin"):
            return Response(
                {"detail": "Owner access required."},
                status=status.HTTP_403_FORBIDDEN
            )
        return None

    def get(self, request):
        check = self._check_owner(request)
        if check: return check

        inquiries = Inquiry.objects.filter(
            listing__owner=request.user
        ).select_related("student", "listing")
        serializer = InquiryReadSerializer(inquiries, many=True)
        return Response(serializer.data)

    def patch(self, request, pk):
        check = self._check_owner(request)
        if check: return check

        try:
            inquiry = Inquiry.objects.get(pk=pk, listing__owner=request.user)
        except Inquiry.DoesNotExist:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

        inquiry.is_read = True
        inquiry.save(update_fields=["is_read"])
        return Response({"detail": "Marked as read."})

    def delete(self, request, pk):
        check = self._check_owner(request)
        if check: return check

        try:
            inquiry = Inquiry.objects.get(pk=pk, listing__owner=request.user)
        except Inquiry.DoesNotExist:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

        inquiry.delete()
        return Response({"detail": "Inquiry deleted."}, status=status.HTTP_204_NO_CONTENT)