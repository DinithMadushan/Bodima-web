# ============================================================
#  GIMSARA — inquiries/models.py
#  Inquiry model — moved here so Django migrations can detect it
# ============================================================

from django.db import models
from users.models import User
from listings.models import Listing


class Inquiry(models.Model):
    TYPE_MESSAGE = "message"
    TYPE_VISIT   = "visit"
    TYPE_CHOICES = [
        (TYPE_MESSAGE, "Message Owner"),      # 💬 Message Owner button
        (TYPE_VISIT,   "Request to Visit"),   # 📞 Request to Visit button
    ]

    listing    = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="inquiries")
    student    = models.ForeignKey(User, on_delete=models.CASCADE, related_name="inquiries_sent")
    message    = models.TextField()
    type       = models.CharField(max_length=10, choices=TYPE_CHOICES, default=TYPE_MESSAGE)
    is_read    = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "inquiries"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student.get_full_name()} → {self.listing.name}"
