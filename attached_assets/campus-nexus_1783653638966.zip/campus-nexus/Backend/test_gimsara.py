# ============================================================
#  GIMSARA — tests/test_gimsara.py
#  Unit tests for:
#    - Reviews API      (ReviewListView, ReviewSummaryView, ReviewCreateView)
#    - Inquiries API    (InquiryCreateView, OwnerInboxView)
#    - Bookings API     (BookingCreateView, BookingConfirmView,
#                        BookingReceiptView, StudentBookingListView,
#                        OwnerBookingListView)
#    - Owner Listings   (OwnerListingView, OwnerListingEditView)
# ============================================================

from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient
from rest_framework import status
import datetime

from users.models import User
from listings.models import Listing
from reviews.models import Review
from inquiries.models import Inquiry
from bookings.models import Booking


# ── HELPERS ───────────────────────────────────────────────────

def make_student(email="student@test.com", password="pass1234"):
    return User.objects.create_user(
        email=email, password=password,
        first_name="Test", last_name="Student", role="student"
    )

def make_owner(email="owner@test.com", password="pass1234"):
    return User.objects.create_user(
        email=email, password=password,
        first_name="Test", last_name="Owner", role="owner"
    )

def make_listing(owner, status=Listing.STATUS_APPROVED):
    return Listing.objects.create(
        name="Sunny Room", area="Kuruna, Negombo",
        location="Negombo", price=8000,
        type=Listing.TYPE_SINGLE, gender=Listing.GENDER_MIXED,
        desc="Nice place.", owner=owner, status=status
    )


# ── REVIEW TESTS ──────────────────────────────────────────────

class ReviewListViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)
        Review.objects.create(
            listing=self.listing, student=self.student,
            rating=4, comment="Good place."
        )

    def test_list_reviews_no_auth_required(self):
        """Anyone can list reviews — no login needed."""
        res = self.client.get("/api/reviews/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_filter_by_listing_id(self):
        res = self.client.get(f"/api/reviews/?listing_id={self.listing.id}")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_filter_by_rating(self):
        res = self.client.get("/api/reviews/?rating=4")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_filter_wrong_rating_returns_empty(self):
        res = self.client.get("/api/reviews/?rating=1")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 0)


class ReviewSummaryViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)
        Review.objects.create(
            listing=self.listing, student=self.student,
            rating=4, comment="Good."
        )

    def test_summary_returns_avg_and_total(self):
        res = self.client.get(f"/api/reviews/summary/?listing_id={self.listing.id}")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data["total"], 1)
        self.assertEqual(float(res.data["avg_rating"]), 4.0)

    def test_summary_breakdown_has_all_stars(self):
        res = self.client.get(f"/api/reviews/summary/?listing_id={self.listing.id}")
        self.assertIn("breakdown", res.data)
        for star in ["1", "2", "3", "4", "5"]:
            self.assertIn(star, res.data["breakdown"])


class ReviewCreateViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)

    def test_student_can_create_review(self):
        self.client.force_authenticate(self.student)
        res = self.client.post("/api/reviews/create/", {
            "listing": self.listing.id,
            "rating": 5,
            "comment": "Excellent!"
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)

    def test_owner_cannot_create_review(self):
        self.client.force_authenticate(self.owner)
        res = self.client.post("/api/reviews/create/", {
            "listing": self.listing.id,
            "rating": 5,
            "comment": "Excellent!"
        })
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_unauthenticated_cannot_create_review(self):
        res = self.client.post("/api/reviews/create/", {
            "listing": self.listing.id,
            "rating": 5,
            "comment": "Excellent!"
        })
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_duplicate_review_rejected(self):
        self.client.force_authenticate(self.student)
        self.client.post("/api/reviews/create/", {
            "listing": self.listing.id, "rating": 5, "comment": "Great!"
        })
        res = self.client.post("/api/reviews/create/", {
            "listing": self.listing.id, "rating": 3, "comment": "OK."
        })
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_invalid_rating_rejected(self):
        self.client.force_authenticate(self.student)
        res = self.client.post("/api/reviews/create/", {
            "listing": self.listing.id, "rating": 6, "comment": "Too high."
        })
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)


# ── INQUIRY TESTS ─────────────────────────────────────────────

class InquiryCreateViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)

    def test_student_can_send_inquiry(self):
        self.client.force_authenticate(self.student)
        res = self.client.post("/api/inquiries/", {
            "listing": self.listing.id,
            "message": "Is the room available?",
            "type": "message"
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)

    def test_owner_cannot_send_inquiry(self):
        self.client.force_authenticate(self.owner)
        res = self.client.post("/api/inquiries/", {
            "listing": self.listing.id,
            "message": "Testing.",
            "type": "message"
        })
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_unauthenticated_cannot_send_inquiry(self):
        res = self.client.post("/api/inquiries/", {
            "listing": self.listing.id,
            "message": "Hello.",
            "type": "message"
        })
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_visit_type_inquiry(self):
        self.client.force_authenticate(self.student)
        res = self.client.post("/api/inquiries/", {
            "listing": self.listing.id,
            "message": "Can I visit tomorrow?",
            "type": "visit"
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)


class OwnerInboxViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)
        self.inquiry = Inquiry.objects.create(
            listing=self.listing, student=self.student,
            message="Is WiFi included?", type="message"
        )

    def test_owner_can_view_inbox(self):
        self.client.force_authenticate(self.owner)
        res = self.client.get("/api/owner/inbox/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_student_cannot_view_owner_inbox(self):
        self.client.force_authenticate(self.student)
        res = self.client.get("/api/owner/inbox/")
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_owner_can_mark_inquiry_as_read(self):
        self.client.force_authenticate(self.owner)
        res = self.client.patch(f"/api/owner/inbox/{self.inquiry.id}/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.inquiry.refresh_from_db()
        self.assertTrue(self.inquiry.is_read)

    def test_owner_can_delete_inquiry(self):
        self.client.force_authenticate(self.owner)
        res = self.client.delete(f"/api/owner/inbox/{self.inquiry.id}/")
        self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Inquiry.objects.filter(id=self.inquiry.id).exists())


# ── BOOKING TESTS ─────────────────────────────────────────────

class BookingCreateViewTest(TestCase):

    def setUp(self):
        self.client   = APIClient()
        self.owner    = make_owner()
        self.student  = make_student()
        self.listing  = make_listing(self.owner)
        self.future   = (timezone.now().date() + datetime.timedelta(days=10)).isoformat()

    def test_student_can_create_booking(self):
        self.client.force_authenticate(self.student)
        res = self.client.post("/api/bookings/create/", {
            "listing": self.listing.id,
            "move_in_date": self.future,
            "message": "Please confirm."
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)

    def test_owner_cannot_create_booking(self):
        self.client.force_authenticate(self.owner)
        res = self.client.post("/api/bookings/create/", {
            "listing": self.listing.id,
            "move_in_date": self.future,
            "message": ""
        })
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_past_move_in_date_rejected(self):
        self.client.force_authenticate(self.student)
        past = (timezone.now().date() - datetime.timedelta(days=1)).isoformat()
        res = self.client.post("/api/bookings/create/", {
            "listing": self.listing.id,
            "move_in_date": past,
            "message": ""
        })
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_duplicate_pending_booking_rejected(self):
        self.client.force_authenticate(self.student)
        data = {"listing": self.listing.id, "move_in_date": self.future, "message": ""}
        self.client.post("/api/bookings/create/", data)
        res = self.client.post("/api/bookings/create/", data)
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)


class BookingConfirmViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)
        self.booking = Booking.objects.create(
            listing=self.listing, student=self.student,
            move_in_date=timezone.now().date() + datetime.timedelta(days=5),
            status=Booking.STATUS_PENDING
        )

    def test_owner_can_confirm_booking(self):
        self.client.force_authenticate(self.owner)
        res = self.client.patch(
            f"/api/owner/bookings/{self.booking.id}/",
            {"status": "confirmed"}
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, Booking.STATUS_CONFIRMED)

    def test_owner_can_cancel_booking(self):
        self.client.force_authenticate(self.owner)
        res = self.client.patch(
            f"/api/owner/bookings/{self.booking.id}/",
            {"status": "cancelled"}
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)

    def test_student_cannot_confirm_booking(self):
        self.client.force_authenticate(self.student)
        res = self.client.patch(
            f"/api/owner/bookings/{self.booking.id}/",
            {"status": "confirmed"}
        )
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_invalid_status_rejected(self):
        self.client.force_authenticate(self.owner)
        res = self.client.patch(
            f"/api/owner/bookings/{self.booking.id}/",
            {"status": "approved"}
        )
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)


class BookingReceiptViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)
        self.booking = Booking.objects.create(
            listing=self.listing, student=self.student,
            move_in_date=timezone.now().date() + datetime.timedelta(days=5),
            status=Booking.STATUS_CONFIRMED,
            confirmed_at=timezone.now()
        )

    def test_student_can_get_receipt(self):
        self.client.force_authenticate(self.student)
        res = self.client.get(f"/api/bookings/{self.booking.id}/receipt/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn("receipt_id", res.data)

    def test_receipt_not_available_for_pending_booking(self):
        pending = Booking.objects.create(
            listing=self.listing, student=make_student("s2@test.com"),
            move_in_date=timezone.now().date() + datetime.timedelta(days=5),
            status=Booking.STATUS_PENDING
        )
        self.client.force_authenticate(self.student)
        res = self.client.get(f"/api/bookings/{pending.id}/receipt/")
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)


class StudentBookingListViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)
        Booking.objects.create(
            listing=self.listing, student=self.student,
            move_in_date=timezone.now().date() + datetime.timedelta(days=5)
        )

    def test_student_sees_own_bookings(self):
        self.client.force_authenticate(self.student)
        res = self.client.get("/api/bookings/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_owner_cannot_access_student_booking_list(self):
        self.client.force_authenticate(self.owner)
        res = self.client.get("/api/bookings/")
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)


class OwnerBookingListViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()
        self.listing = make_listing(self.owner)
        Booking.objects.create(
            listing=self.listing, student=self.student,
            move_in_date=timezone.now().date() + datetime.timedelta(days=5)
        )

    def test_owner_sees_bookings_for_their_listings(self):
        self.client.force_authenticate(self.owner)
        res = self.client.get("/api/owner/bookings/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_student_cannot_access_owner_booking_list(self):
        self.client.force_authenticate(self.student)
        res = self.client.get("/api/owner/bookings/")
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)


# ── OWNER LISTING TESTS ───────────────────────────────────────

class OwnerListingViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.student = make_student()

    def test_owner_can_view_own_listings(self):
        make_listing(self.owner)
        self.client.force_authenticate(self.owner)
        res = self.client.get("/api/owner/listings/")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res.data), 1)

    def test_student_cannot_access_owner_listings(self):
        self.client.force_authenticate(self.student)
        res = self.client.get("/api/owner/listings/")
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_owner_can_create_listing(self):
        self.client.force_authenticate(self.owner)
        res = self.client.post("/api/owner/listings/", {
            "name": "New Room",
            "area": "Wattala",
            "location": "Wattala",
            "price": 9000,
            "type": "Single Room",
            "gender": "Mixed",
            "desc": "Clean room.",
            "amenities": "WiFi,Meals"
        })
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Listing.objects.filter(owner=self.owner).count(), 1)

    def test_new_listing_status_is_pending(self):
        self.client.force_authenticate(self.owner)
        self.client.post("/api/owner/listings/", {
            "name": "New Room", "area": "Wattala", "location": "Wattala",
            "price": 9000, "type": "Single Room", "gender": "Mixed", "desc": "Clean."
        })
        listing = Listing.objects.get(owner=self.owner)
        self.assertEqual(listing.status, Listing.STATUS_PENDING)


class OwnerListingEditViewTest(TestCase):

    def setUp(self):
        self.client  = APIClient()
        self.owner   = make_owner()
        self.other   = make_owner("other@test.com")
        self.listing = make_listing(self.owner)

    def test_owner_can_edit_own_listing(self):
        self.client.force_authenticate(self.owner)
        res = self.client.put(f"/api/owner/listings/{self.listing.id}/", {
            "name": "Updated Room", "area": "Negombo", "location": "Negombo",
            "price": 10000, "type": "Single Room", "gender": "Mixed", "desc": "Updated."
        })
        self.assertEqual(res.status_code, status.HTTP_200_OK)

    def test_edit_resets_status_to_pending(self):
        self.client.force_authenticate(self.owner)
        self.client.put(f"/api/owner/listings/{self.listing.id}/", {
            "name": "Updated", "area": "Negombo", "location": "Negombo",
            "price": 10000, "type": "Single Room", "gender": "Mixed", "desc": "."
        })
        self.listing.refresh_from_db()
        self.assertEqual(self.listing.status, Listing.STATUS_PENDING)

    def test_owner_cannot_edit_others_listing(self):
        self.client.force_authenticate(self.other)
        res = self.client.put(f"/api/owner/listings/{self.listing.id}/", {
            "name": "Hacked", "area": "X", "location": "Negombo",
            "price": 1, "type": "Single Room", "gender": "Mixed", "desc": "."
        })
        self.assertEqual(res.status_code, status.HTTP_404_NOT_FOUND)

    def test_owner_can_delete_own_listing(self):
        self.client.force_authenticate(self.owner)
        res = self.client.delete(f"/api/owner/listings/{self.listing.id}/")
        self.assertEqual(res.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Listing.objects.filter(id=self.listing.id).exists())