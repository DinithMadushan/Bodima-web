from django.urls import path
from . import views

urlpatterns = [
    path("conversations/",                           views.ConversationListView.as_view(),    name="conv_list"),
    path("conversations/<int:pk>/",                  views.ConversationDetailView.as_view(),  name="conv_detail"),
    path("conversations/<int:pk>/send/",             views.SendMessageView.as_view(),         name="msg_send"),
    path("conversations/<int:pk>/read/",             views.MarkConversationReadView.as_view(), name="msg_read"),
    path("<int:msg_id>/delete/",                     views.DeleteMessageView.as_view(),       name="msg_delete"),
    path("unread/",                                  views.UnreadCountView.as_view(),         name="msg_unread"),
]
