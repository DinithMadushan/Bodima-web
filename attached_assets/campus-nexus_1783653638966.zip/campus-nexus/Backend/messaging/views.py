# ============================================================
#  messaging/views.py
#  Bidirectional messaging between student and owner.
#
#  Endpoints:
#    GET  /api/messages/conversations/              — list all conversations for current user
#    POST /api/messages/conversations/              — start/get conversation (student initiates)
#    GET  /api/messages/conversations/<id>/         — get conversation + all messages
#    POST /api/messages/conversations/<id>/send/    — send a message in conversation
#    PATCH /api/messages/conversations/<id>/read/   — mark all as read
#    DELETE /api/messages/<msg_id>/                 — delete own message
# ============================================================

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from rest_framework.permissions import IsAuthenticated

from .models import Conversation, Message
from listings.models import Listing
from users.models import User


# ── Serializers ───────────────────────────────────────────────

class MessageSerializer(serializers.ModelSerializer):
    sender_name = serializers.SerializerMethodField()
    sender_role = serializers.SerializerMethodField()

    class Meta:
        model  = Message
        fields = ["id", "sender", "sender_name", "sender_role", "body", "is_read", "created_at"]

    def get_sender_name(self, obj):
        return obj.sender.get_full_name()

    def get_sender_role(self, obj):
        return obj.sender.role


class ConversationListSerializer(serializers.ModelSerializer):
    listing_name     = serializers.SerializerMethodField()
    listing_area     = serializers.SerializerMethodField()
    other_party_name = serializers.SerializerMethodField()
    last_message     = serializers.SerializerMethodField()
    unread_count     = serializers.SerializerMethodField()

    class Meta:
        model  = Conversation
        fields = [
            "id", "listing", "listing_name", "listing_area",
            "other_party_name", "last_message", "unread_count", "updated_at",
        ]

    def _current_user(self):
        return self.context["request"].user

    def get_listing_name(self, obj):
        return obj.listing.name

    def get_listing_area(self, obj):
        return obj.listing.area

    def get_other_party_name(self, obj):
        user = self._current_user()
        return obj.owner.get_full_name() if user == obj.student else obj.student.get_full_name()

    def get_last_message(self, obj):
        msg = obj.messages.last()
        if not msg:
            return None
        return {
            "body":       msg.body[:100],
            "sender_name": msg.sender.get_full_name(),
            "created_at": msg.created_at,
        }

    def get_unread_count(self, obj):
        user = self._current_user()
        if user == obj.student:
            return obj.unread_for_student
        return obj.unread_for_owner


class ConversationDetailSerializer(serializers.ModelSerializer):
    messages     = MessageSerializer(many=True, read_only=True)
    listing_name = serializers.SerializerMethodField()
    listing_area = serializers.SerializerMethodField()
    listing_price = serializers.SerializerMethodField()
    student_name = serializers.SerializerMethodField()
    owner_name   = serializers.SerializerMethodField()

    class Meta:
        model  = Conversation
        fields = [
            "id", "listing", "listing_name", "listing_area", "listing_price",
            "student_name", "owner_name", "messages", "created_at", "updated_at",
        ]

    def get_listing_name(self, obj):  return obj.listing.name
    def get_listing_area(self, obj):  return obj.listing.area
    def get_listing_price(self, obj): return obj.listing.price
    def get_student_name(self, obj):  return obj.student.get_full_name()
    def get_owner_name(self, obj):    return obj.owner.get_full_name()


# ── Views ─────────────────────────────────────────────────────

class ConversationListView(APIView):
    """
    GET  /api/messages/conversations/
    List all conversations for the current user (both student and owner).

    POST /api/messages/conversations/
    Start or retrieve a conversation.
    Body: { "listing_id": 5 }
    Student-only. Owner of that listing is automatically set.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if user.role == "student":
            qs = Conversation.objects.filter(student=user).select_related("listing", "owner")
        elif user.role in ("owner", "admin"):
            qs = Conversation.objects.filter(owner=user).select_related("listing", "student")
        else:
            return Response({"detail": "Access denied."}, status=status.HTTP_403_FORBIDDEN)

        serializer = ConversationListSerializer(qs, many=True, context={"request": request})
        return Response(serializer.data)

    def post(self, request):
        if request.user.role != "student":
            return Response(
                {"detail": "Only students can initiate conversations."},
                status=status.HTTP_403_FORBIDDEN,
            )

        listing_id = request.data.get("listing_id")
        if not listing_id:
            return Response({"detail": "listing_id is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            listing = Listing.objects.select_related("owner").get(pk=listing_id)
        except Listing.DoesNotExist:
            return Response({"detail": "Listing not found."}, status=status.HTTP_404_NOT_FOUND)

        # Get or create the conversation
        conversation, created = Conversation.objects.get_or_create(
            listing=listing,
            student=request.user,
            owner=listing.owner,
        )

        serializer = ConversationDetailSerializer(conversation)
        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
        )


class ConversationDetailView(APIView):
    """
    GET  /api/messages/conversations/<id>/
    Returns full conversation with all messages.
    Also marks messages from the other party as read.

    PATCH /api/messages/conversations/<id>/read/
    (alias — see MarkConversationReadView)
    """
    permission_classes = [IsAuthenticated]

    def _get_conversation(self, request, pk):
        user = request.user
        try:
            if user.role == "student":
                return Conversation.objects.get(pk=pk, student=user)
            else:
                return Conversation.objects.get(pk=pk, owner=user)
        except Conversation.DoesNotExist:
            return None

    def get(self, request, pk):
        conversation = self._get_conversation(request, pk)
        if not conversation:
            return Response({"detail": "Conversation not found."}, status=status.HTTP_404_NOT_FOUND)

        # Mark incoming messages as read
        other_party = conversation.owner if request.user == conversation.student else conversation.student
        conversation.messages.filter(sender=other_party, is_read=False).update(is_read=True)

        serializer = ConversationDetailSerializer(conversation)
        return Response(serializer.data)


class SendMessageView(APIView):
    """
    POST /api/messages/conversations/<id>/send/
    Body: { "body": "Is the room still available?" }

    Either student or owner can send a message in their conversation.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        user = request.user
        try:
            if user.role == "student":
                conversation = Conversation.objects.get(pk=pk, student=user)
            else:
                conversation = Conversation.objects.get(pk=pk, owner=user)
        except Conversation.DoesNotExist:
            return Response({"detail": "Conversation not found."}, status=status.HTTP_404_NOT_FOUND)

        body = request.data.get("body", "").strip()
        if not body:
            return Response({"detail": "Message body cannot be empty."}, status=status.HTTP_400_BAD_REQUEST)

        if len(body) > 2000:
            return Response({"detail": "Message too long (max 2000 chars)."}, status=status.HTTP_400_BAD_REQUEST)

        message = Message.objects.create(
            conversation=conversation,
            sender=user,
            body=body,
        )

        # Touch conversation.updated_at so it bubbles to top of list
        conversation.save(update_fields=["updated_at"])

        serializer = MessageSerializer(message)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class MarkConversationReadView(APIView):
    """
    PATCH /api/messages/conversations/<id>/read/
    Marks all incoming (unread) messages in this conversation as read.
    """
    permission_classes = [IsAuthenticated]

    def patch(self, request, pk):
        user = request.user
        try:
            if user.role == "student":
                conversation = Conversation.objects.get(pk=pk, student=user)
                other_party  = conversation.owner
            else:
                conversation = Conversation.objects.get(pk=pk, owner=user)
                other_party  = conversation.student
        except Conversation.DoesNotExist:
            return Response({"detail": "Conversation not found."}, status=status.HTTP_404_NOT_FOUND)

        updated = conversation.messages.filter(sender=other_party, is_read=False).update(is_read=True)
        return Response({"marked_read": updated})


class DeleteMessageView(APIView):
    """
    DELETE /api/messages/<msg_id>/
    Only the sender can delete their own message.
    """
    permission_classes = [IsAuthenticated]

    def delete(self, request, msg_id):
        try:
            message = Message.objects.get(pk=msg_id, sender=request.user)
        except Message.DoesNotExist:
            return Response({"detail": "Message not found or not yours."}, status=status.HTTP_404_NOT_FOUND)

        message.delete()
        return Response({"detail": "Message deleted."}, status=status.HTTP_204_NO_CONTENT)


class UnreadCountView(APIView):
    """
    GET /api/messages/unread/
    Returns total unread message count for the current user.
    Used by navbar badge.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if user.role == "student":
            count = Message.objects.filter(
                conversation__student=user,
                sender=user.__class__.objects.filter(
                    role__in=["owner", "admin"]
                ).values("id"),
                is_read=False,
            ).count()
            # Simpler query:
            count = Message.objects.filter(
                conversation__student=user,
                is_read=False,
            ).exclude(sender=user).count()
        else:
            count = Message.objects.filter(
                conversation__owner=user,
                is_read=False,
            ).exclude(sender=user).count()

        return Response({"unread": count})
