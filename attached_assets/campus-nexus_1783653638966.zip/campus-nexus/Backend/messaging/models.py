# ============================================================
#  messaging/models.py
#  Bidirectional messaging between student and boarding owner
#  about a specific listing.
# ============================================================

from django.db import models
from users.models import User
from listings.models import Listing


class Conversation(models.Model):
    """
    A thread between one student and one owner about one listing.
    Unique constraint prevents duplicate threads.
    """
    listing  = models.ForeignKey(Listing,  on_delete=models.CASCADE, related_name="conversations")
    student  = models.ForeignKey(User, on_delete=models.CASCADE, related_name="student_conversations")
    owner    = models.ForeignKey(User, on_delete=models.CASCADE, related_name="owner_conversations")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "conversations"
        unique_together = [("listing", "student", "owner")]
        ordering = ["-updated_at"]

    @property
    def unread_for_student(self):
        return self.messages.filter(sender=self.owner, is_read=False).count()

    @property
    def unread_for_owner(self):
        return self.messages.filter(sender=self.student, is_read=False).count()

    def __str__(self):
        return f"{self.student.email} ↔ {self.owner.email} re: {self.listing.name}"


class Message(models.Model):
    """
    A single message in a conversation. Either party can send.
    """
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name="messages")
    sender       = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sent_messages")
    body         = models.TextField()
    is_read      = models.BooleanField(default=False)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "messages"
        ordering = ["created_at"]

    def __str__(self):
        return f"[{self.conversation_id}] {self.sender.email}: {self.body[:60]}"
