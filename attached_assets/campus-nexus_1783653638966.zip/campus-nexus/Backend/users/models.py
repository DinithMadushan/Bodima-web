# ============================================================
#  DINITH — users/models.py
#  Custom User model for බෝdima.lk
#
#  Matches Thamshi's:
#    index.html   → #loginForm    (email + password)
#    register.html → role-card   (student / owner)
#    register.html → row-inputs  (first_name, last_name, email, phone, password)
# ============================================================

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models


class UserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Email is required")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("role", "admin")
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    # Role choices — must match register.html #roleStudent / #roleOwner IDs
    ROLE_STUDENT = "student"
    ROLE_OWNER   = "owner"
    ROLE_ADMIN   = "admin"
    ROLE_CHOICES = [
        (ROLE_STUDENT, "Student"),
        (ROLE_OWNER,   "Boarding Owner"),
        (ROLE_ADMIN,   "Administrator"),
    ]

    email       = models.EmailField(unique=True)
    first_name  = models.CharField(max_length=100)           # register.html "First Name"
    last_name   = models.CharField(max_length=100)           # register.html "Last Name"
    phone       = models.CharField(max_length=20, blank=True) # register.html "Phone Number"
    role        = models.CharField(max_length=10, choices=ROLE_CHOICES, default=ROLE_STUDENT)
    is_active   = models.BooleanField(default=True)
    is_staff    = models.BooleanField(default=False)
    created_at  = models.DateTimeField(auto_now_add=True)

    objects = UserManager()

    USERNAME_FIELD  = "email"
    REQUIRED_FIELDS = ["first_name", "last_name"]

    class Meta:
        db_table = "users"

    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"

    def __str__(self):
        return f"{self.email} ({self.role})"
