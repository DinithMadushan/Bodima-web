# ============================================================
#  DINITH — users/serializers.py
#  Serializers for login and registration
# ============================================================

from django.contrib.auth import authenticate
from rest_framework import serializers
from .models import User


class RegisterSerializer(serializers.ModelSerializer):
    """
    Matches register.html fields:
      - first_name   (input placeholder "First Name")
      - last_name    (input placeholder "Last Name")
      - email        (input type email)
      - phone        (input type tel, "Phone Number")
      - password     (input "Create Password")
      - confirm_password (input "Confirm Password")
      - role         ('student' or 'owner' from roleStudent/roleOwner cards)
    """
    confirm_password = serializers.CharField(write_only=True)
    role = serializers.ChoiceField(choices=["student", "owner"])

    class Meta:
        model  = User
        fields = ["first_name", "last_name", "email", "phone",
                  "password", "confirm_password", "role"]
        extra_kwargs = {"password": {"write_only": True}}

    def validate(self, data):
        if data["password"] != data["confirm_password"]:
            raise serializers.ValidationError(
                {"confirm_password": "Passwords do not match."}
            )
        if len(data["password"]) < 8:
            raise serializers.ValidationError(
                {"password": "Password must be at least 8 characters."}
            )
        return data

    def create(self, validated_data):
        validated_data.pop("confirm_password")
        return User.objects.create_user(**validated_data)


class LoginSerializer(serializers.Serializer):
    """
    Matches index.html #loginForm fields:
      - email    (input type email)
      - password (input type password)
    """
    email    = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        user = authenticate(username=data["email"], password=data["password"])
        if not user:
            raise serializers.ValidationError(
                {"non_field_errors": "Invalid email or password."}
            )
        if not user.is_active:
            raise serializers.ValidationError(
                {"non_field_errors": "Your account has been disabled."}
            )
        data["user"] = user
        return data


class UserPublicSerializer(serializers.ModelSerializer):
    """Minimal user info returned in listing detail (owner block in details.html)."""
    full_name = serializers.SerializerMethodField()

    class Meta:
        model  = User
        fields = ["id", "full_name", "created_at"]

    def get_full_name(self, obj):
        return obj.get_full_name()
