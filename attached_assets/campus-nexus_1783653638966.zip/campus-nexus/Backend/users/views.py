# ============================================================
#  DINITH — users/views.py
#  Login, Logout, Token Refresh
#
#  Wires up:
#    index.html  #loginForm  "Sign In →" button
#    index.html  logout nav link
# ============================================================

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.exceptions import TokenError

from .serializers import LoginSerializer, RegisterSerializer
from .models import User


class LoginView(APIView):
    """
    POST /api/auth/login/

    Request body (matches index.html #loginForm):
        { "email": "...", "password": "..." }

    Response:
        {
            "access":     "<jwt access token>",
            "refresh":    "<jwt refresh token>",
            "role":       "student" | "owner" | "admin",
            "full_name":  "Kasun Perera"
        }

    Frontend JS must read 'role' and redirect:
        student → home.html
        owner   → owner-dashboard.html
        admin   → admin.html
    """
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user = serializer.validated_data["user"]
        refresh = RefreshToken.for_user(user)

        return Response({
            "access":    str(refresh.access_token),
            "refresh":   str(refresh),
            "role":      user.role,
            "full_name": user.get_full_name(),
        }, status=status.HTTP_200_OK)


class LogoutView(APIView):
    """
    POST /api/auth/logout/
    Blacklists the refresh token so it can no longer be used.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        refresh_token = request.data.get("refresh")
        if not refresh_token:
            return Response(
                {"detail": "Refresh token is required."},
                status=status.HTTP_400_BAD_REQUEST
            )
        try:
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({"detail": "Logged out successfully."}, status=status.HTTP_200_OK)
        except TokenError:
            return Response({"detail": "Invalid token."}, status=status.HTTP_400_BAD_REQUEST)

class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        user = serializer.save()
        return Response(
            {"detail": "Account created successfully."},
            status=status.HTTP_201_CREATED
        )


# ── Admin User Management ─────────────────────────────────────

class UserSerializer(serializers.ModelSerializer):
    full_name    = serializers.SerializerMethodField()
    listing_count = serializers.SerializerMethodField()

    class Meta:
        model  = User
        fields = [
            "id", "email", "full_name", "first_name", "last_name",
            "phone", "role", "is_active", "is_staff", "created_at", "listing_count",
        ]

    def get_full_name(self, obj):
        return obj.get_full_name()

    def get_listing_count(self, obj):
        if obj.role == "owner":
            return obj.listings.count()
        return 0


class AdminUserListView(APIView):
    """
    GET /api/admin/users/
    Returns all users. Supports ?role=student|owner|admin and ?is_active=true|false
    """
    permission_classes = [IsAdminUser]

    def get(self, request):
        qs = User.objects.all().order_by("-created_at")
        role      = request.query_params.get("role")
        is_active = request.query_params.get("is_active")

        if role:
            qs = qs.filter(role=role)
        if is_active is not None:
            qs = qs.filter(is_active=is_active.lower() == "true")

        serializer = UserSerializer(qs, many=True)
        return Response(serializer.data)


class AdminUserActionView(APIView):
    """
    GET    /api/admin/users/<id>/   — get single user detail
    PATCH  /api/admin/users/<id>/   — update user (activate/deactivate/change role)
    DELETE /api/admin/users/<id>/   — soft-delete (deactivate) user

    PATCH body examples:
      { "is_active": false }          — deactivate / ban user
      { "is_active": true }           — re-activate user
      { "role": "owner" }             — change role
      { "is_staff": true }            — grant admin access
    """
    permission_classes = [IsAdminUser]

    def _get_user(self, pk):
        try:
            return User.objects.get(pk=pk)
        except User.DoesNotExist:
            return None

    def get(self, request, pk):
        user = self._get_user(pk)
        if not user:
            return Response({"detail": "User not found."}, status=status.HTTP_404_NOT_FOUND)
        serializer = UserSerializer(user)
        return Response(serializer.data)

    def patch(self, request, pk):
        user = self._get_user(pk)
        if not user:
            return Response({"detail": "User not found."}, status=status.HTTP_404_NOT_FOUND)

        allowed_fields = {"is_active", "role", "is_staff"}
        update_fields  = []

        for field in allowed_fields:
            if field in request.data:
                value = request.data[field]
                # Validate role
                if field == "role" and value not in [User.ROLE_STUDENT, User.ROLE_OWNER, User.ROLE_ADMIN]:
                    return Response(
                        {"role": f"Must be one of: {User.ROLE_STUDENT}, {User.ROLE_OWNER}, {User.ROLE_ADMIN}."},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                setattr(user, field, value)
                update_fields.append(field)

        if not update_fields:
            return Response({"detail": "No valid fields to update."}, status=status.HTTP_400_BAD_REQUEST)

        user.save(update_fields=update_fields)
        serializer = UserSerializer(user)
        return Response(serializer.data)

    def delete(self, request, pk):
        user = self._get_user(pk)
        if not user:
            return Response({"detail": "User not found."}, status=status.HTTP_404_NOT_FOUND)

        # Soft delete — never hard-delete users
        user.is_active = False
        user.save(update_fields=["is_active"])
        return Response({"detail": f"User {user.email} deactivated."}, status=status.HTTP_200_OK)