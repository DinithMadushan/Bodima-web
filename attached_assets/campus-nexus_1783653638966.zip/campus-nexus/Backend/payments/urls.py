from django.urls import path
from . import views

urlpatterns = [
    # Stripe
    path("stripe/create/",           views.StripeCreatePaymentIntentView.as_view(), name="stripe_create"),
    path("stripe/confirm/",          views.StripeConfirmPaymentView.as_view(),      name="stripe_confirm"),
    path("webhook/stripe/",          views.StripeWebhookView.as_view(),             name="stripe_webhook"),

    # PayPal
    path("paypal/create/",           views.PayPalCreateOrderView.as_view(),         name="paypal_create"),
    path("paypal/capture/<str:order_id>/", views.PayPalCaptureOrderView.as_view(), name="paypal_capture"),

    # Status / History
    path("history/",                 views.PaymentHistoryView.as_view(),            name="payment_history"),
    path("<int:booking_id>/",        views.PaymentStatusView.as_view(),             name="payment_status"),
]
