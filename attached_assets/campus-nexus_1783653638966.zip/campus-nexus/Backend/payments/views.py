# ============================================================
#  payments/views.py
#  Stripe + PayPal payment gateway integration
#
#  Endpoints:
#    POST /api/payments/stripe/create/         — create Stripe PaymentIntent
#    POST /api/payments/stripe/confirm/        — confirm Stripe payment
#    POST /api/payments/paypal/create/         — create PayPal order
#    POST /api/payments/paypal/capture/<id>/   — capture PayPal order
#    POST /api/payments/webhook/stripe/        — Stripe webhook
#    GET  /api/payments/<booking_id>/          — payment status for a booking
#    GET  /api/payments/history/               — student's payment history
#    GET  /api/admin/payments/                 — admin: all payments
# ============================================================

import stripe
import paypalrestsdk
import hashlib
import hmac
import json
import logging

from django.conf import settings
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny

from bookings.models import Booking
from .models import Payment

logger = logging.getLogger(__name__)


# ── Serializers ───────────────────────────────────────────────

class PaymentSerializer(serializers.ModelSerializer):
    booking_details = serializers.SerializerMethodField()

    class Meta:
        model  = Payment
        fields = [
            "id", "booking", "booking_details", "amount", "currency",
            "payment_method", "payment_type", "status",
            "transaction_ref", "paid_at", "created_at",
        ]

    def get_booking_details(self, obj):
        return {
            "listing_name": obj.booking.listing.name,
            "listing_area": obj.booking.listing.area,
            "move_in_date": obj.booking.move_in_date,
        }


# ── Helpers ───────────────────────────────────────────────────

def _configure_stripe():
    stripe.api_key = settings.STRIPE_SECRET_KEY


def _configure_paypal():
    paypalrestsdk.configure({
        "mode":        settings.PAYPAL_MODE,      # "sandbox" or "live"
        "client_id":   settings.PAYPAL_CLIENT_ID,
        "client_secret": settings.PAYPAL_CLIENT_SECRET,
    })


def _get_booking_or_403(request, booking_id):
    """Return booking only if the requesting user is the student."""
    try:
        booking = Booking.objects.select_related("listing", "listing__owner").get(pk=booking_id)
    except Booking.DoesNotExist:
        return None, Response({"detail": "Booking not found."}, status=status.HTTP_404_NOT_FOUND)
    if booking.student != request.user:
        return None, Response({"detail": "Not your booking."}, status=status.HTTP_403_FORBIDDEN)
    return booking, None


# ── Stripe ────────────────────────────────────────────────────

class StripeCreatePaymentIntentView(APIView):
    """
    POST /api/payments/stripe/create/
    Body: { "booking_id": 5, "payment_type": "deposit" }

    Creates a Stripe PaymentIntent and stores a pending Payment row.
    Returns { client_secret, payment_id } to the frontend.
    The frontend uses Stripe.js to complete the charge with client_secret.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        booking_id   = request.data.get("booking_id")
        payment_type = request.data.get("payment_type", Payment.TYPE_DEPOSIT)

        if not booking_id:
            return Response({"detail": "booking_id is required."}, status=status.HTTP_400_BAD_REQUEST)

        booking, err = _get_booking_or_403(request, booking_id)
        if err:
            return err

        if booking.status != Booking.STATUS_CONFIRMED:
            return Response(
                {"detail": "Payment only allowed for confirmed bookings."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Determine amount based on payment type
        listing = booking.listing
        amount_map = {
            Payment.TYPE_DEPOSIT:    listing.price * listing.deposit_months,
            Payment.TYPE_FIRST_RENT: listing.price,
            Payment.TYPE_MONTHLY:    listing.price,
        }
        amount_lkr = amount_map.get(payment_type, listing.price)

        # Stripe uses smallest currency unit (cents/paisa). LKR has no subunit → multiply by 100
        amount_cents = int(amount_lkr * 100)

        try:
            _configure_stripe()
            intent = stripe.PaymentIntent.create(
                amount   = amount_cents,
                currency = "lkr",
                metadata = {
                    "booking_id":   booking.id,
                    "student_email": request.user.email,
                    "listing_name": listing.name,
                },
                description = f"Campus Nexus: {listing.name} — {payment_type}",
            )
        except stripe.error.StripeError as e:
            logger.error("Stripe error: %s", str(e))
            return Response({"detail": str(e)}, status=status.HTTP_502_BAD_GATEWAY)

        payment = Payment.objects.create(
            booking                  = booking,
            payer                    = request.user,
            amount                   = amount_lkr,
            currency                 = "LKR",
            payment_method           = Payment.METHOD_STRIPE,
            payment_type             = payment_type,
            status                   = Payment.STATUS_PENDING,
            stripe_payment_intent_id = intent["id"],
            stripe_client_secret     = intent["client_secret"],
        )

        return Response({
            "payment_id":    payment.id,
            "client_secret": intent["client_secret"],
            "amount":        float(amount_lkr),
            "currency":      "LKR",
        }, status=status.HTTP_201_CREATED)


class StripeConfirmPaymentView(APIView):
    """
    POST /api/payments/stripe/confirm/
    Body: { "payment_id": 7, "payment_intent_id": "pi_xxx" }

    Called by frontend after Stripe.js confirms the payment to sync DB status.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        payment_id        = request.data.get("payment_id")
        payment_intent_id = request.data.get("payment_intent_id")

        try:
            payment = Payment.objects.get(pk=payment_id, payer=request.user)
        except Payment.DoesNotExist:
            return Response({"detail": "Payment not found."}, status=status.HTTP_404_NOT_FOUND)

        try:
            _configure_stripe()
            intent = stripe.PaymentIntent.retrieve(payment_intent_id or payment.stripe_payment_intent_id)
        except stripe.error.StripeError as e:
            return Response({"detail": str(e)}, status=status.HTTP_502_BAD_GATEWAY)

        if intent["status"] == "succeeded":
            payment.status        = Payment.STATUS_COMPLETED
            payment.transaction_ref = intent["id"]
            payment.paid_at       = timezone.now()
            payment.save(update_fields=["status", "transaction_ref", "paid_at"])
            return Response({"status": "completed", "payment_id": payment.id})
        elif intent["status"] in ("requires_payment_method", "canceled"):
            payment.status = Payment.STATUS_FAILED
            payment.save(update_fields=["status"])
            return Response({"status": "failed", "payment_id": payment.id})
        else:
            return Response({"status": intent["status"], "payment_id": payment.id})


@method_decorator(csrf_exempt, name="dispatch")
class StripeWebhookView(APIView):
    """
    POST /api/payments/webhook/stripe/
    Stripe sends signed events here.  Validates signature then updates DB.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        payload   = request.body
        sig_header = request.META.get("HTTP_STRIPE_SIGNATURE", "")

        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
            )
        except (ValueError, stripe.error.SignatureVerificationError) as e:
            logger.warning("Stripe webhook signature failed: %s", str(e))
            return Response({"detail": "Invalid signature."}, status=status.HTTP_400_BAD_REQUEST)

        if event["type"] == "payment_intent.succeeded":
            pi = event["data"]["object"]
            Payment.objects.filter(
                stripe_payment_intent_id=pi["id"]
            ).update(
                status          = Payment.STATUS_COMPLETED,
                transaction_ref = pi["id"],
                paid_at         = timezone.now(),
            )

        elif event["type"] == "payment_intent.payment_failed":
            pi = event["data"]["object"]
            Payment.objects.filter(
                stripe_payment_intent_id=pi["id"]
            ).update(status=Payment.STATUS_FAILED)

        elif event["type"] == "charge.refunded":
            charge = event["data"]["object"]
            pi_id  = charge.get("payment_intent")
            if pi_id:
                Payment.objects.filter(
                    stripe_payment_intent_id=pi_id
                ).update(status=Payment.STATUS_REFUNDED)

        return Response({"received": True})


# ── PayPal ────────────────────────────────────────────────────

class PayPalCreateOrderView(APIView):
    """
    POST /api/payments/paypal/create/
    Body: { "booking_id": 5, "payment_type": "deposit" }

    Creates a PayPal Order in CAPTURE mode and returns { order_id, approve_url }.
    Frontend redirects user to approve_url, then calls /paypal/capture/<order_id>/.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        booking_id   = request.data.get("booking_id")
        payment_type = request.data.get("payment_type", Payment.TYPE_DEPOSIT)

        if not booking_id:
            return Response({"detail": "booking_id is required."}, status=status.HTTP_400_BAD_REQUEST)

        booking, err = _get_booking_or_403(request, booking_id)
        if err:
            return err

        if booking.status != Booking.STATUS_CONFIRMED:
            return Response(
                {"detail": "Payment only allowed for confirmed bookings."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        listing = booking.listing
        amount_map = {
            Payment.TYPE_DEPOSIT:    listing.price * listing.deposit_months,
            Payment.TYPE_FIRST_RENT: listing.price,
            Payment.TYPE_MONTHLY:    listing.price,
        }
        amount_lkr = float(amount_map.get(payment_type, listing.price))

        try:
            _configure_paypal()
            order = paypalrestsdk.Payment({
                "intent": "sale",
                "payer":  {"payment_method": "paypal"},
                "redirect_urls": {
                    "return_url": f"{settings.FRONTEND_BASE_URL}/payment-success.html",
                    "cancel_url": f"{settings.FRONTEND_BASE_URL}/payment-cancel.html",
                },
                "transactions": [{
                    "item_list": {
                        "items": [{
                            "name":     listing.name,
                            "sku":      str(listing.id),
                            "price":    f"{amount_lkr:.2f}",
                            "currency": "USD",
                            "quantity": 1,
                        }]
                    },
                    "amount": {
                        "total":    f"{amount_lkr:.2f}",
                        "currency": "USD",
                    },
                    "description": f"Campus Nexus: {listing.name} — {payment_type}",
                }],
            })
        except Exception as e:
            logger.error("PayPal create order error: %s", str(e))
            return Response({"detail": str(e)}, status=status.HTTP_502_BAD_GATEWAY)

        if not order.create():
            logger.error("PayPal order creation failed: %s", order.error)
            return Response({"detail": str(order.error)}, status=status.HTTP_502_BAD_GATEWAY)

        # Find approval URL
        approve_url = next(
            (link.href for link in order.links if link.rel == "approval_url"), None
        )

        payment = Payment.objects.create(
            booking         = booking,
            payer           = request.user,
            amount          = amount_lkr,
            currency        = "USD",
            payment_method  = Payment.METHOD_PAYPAL,
            payment_type    = payment_type,
            status          = Payment.STATUS_PENDING,
            paypal_order_id = order.id,
        )

        return Response({
            "payment_id":   payment.id,
            "order_id":     order.id,
            "approve_url":  approve_url,
            "amount":       amount_lkr,
        }, status=status.HTTP_201_CREATED)


class PayPalCaptureOrderView(APIView):
    """
    POST /api/payments/paypal/capture/<order_id>/
    Body: { "payer_id": "BUYER123" }

    Captures a PayPal payment after user approves. Called by frontend
    after returning from PayPal redirect with ?paymentId=...&PayerID=...
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, order_id):
        payer_id = request.data.get("payer_id")
        if not payer_id:
            return Response({"detail": "payer_id is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            payment_obj = Payment.objects.get(
                paypal_order_id=order_id, payer=request.user
            )
        except Payment.DoesNotExist:
            return Response({"detail": "Payment not found."}, status=status.HTTP_404_NOT_FOUND)

        try:
            _configure_paypal()
            paypal_payment = paypalrestsdk.Payment.find(order_id)
            executed = paypal_payment.execute({"payer_id": payer_id})
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_502_BAD_GATEWAY)

        if executed:
            capture_id = None
            try:
                capture_id = paypal_payment.transactions[0].related_resources[0].sale.id
            except Exception:
                pass

            payment_obj.status          = Payment.STATUS_COMPLETED
            payment_obj.paypal_capture_id = capture_id
            payment_obj.transaction_ref = order_id
            payment_obj.paid_at         = timezone.now()
            payment_obj.save(update_fields=["status", "paypal_capture_id", "transaction_ref", "paid_at"])

            return Response({
                "status":     "completed",
                "payment_id": payment_obj.id,
                "capture_id": capture_id,
            })
        else:
            payment_obj.status = Payment.STATUS_FAILED
            payment_obj.save(update_fields=["status"])
            return Response({"status": "failed", "detail": str(paypal_payment.error)}, status=status.HTTP_400_BAD_REQUEST)


# ── Payment Status / History ──────────────────────────────────

class PaymentStatusView(APIView):
    """
    GET /api/payments/<booking_id>/
    Returns payment records for a specific booking (student or owner).
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, booking_id):
        try:
            booking = Booking.objects.get(pk=booking_id)
        except Booking.DoesNotExist:
            return Response({"detail": "Booking not found."}, status=status.HTTP_404_NOT_FOUND)

        if request.user not in (booking.student, booking.listing.owner) and not request.user.is_staff:
            return Response({"detail": "Not allowed."}, status=status.HTTP_403_FORBIDDEN)

        payments = Payment.objects.filter(booking=booking)
        serializer = PaymentSerializer(payments, many=True)
        return Response(serializer.data)


class PaymentHistoryView(APIView):
    """
    GET /api/payments/history/
    Student sees their own payment history.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        payments = Payment.objects.filter(payer=request.user).select_related("booking", "booking__listing")
        serializer = PaymentSerializer(payments, many=True)
        return Response(serializer.data)


class AdminPaymentListView(APIView):
    """
    GET /api/admin/payments/
    Admin sees all payments with optional status filter.
    """
    permission_classes = [IsAdminUser]

    def get(self, request):
        qs = Payment.objects.select_related("booking", "payer", "booking__listing").all()
        pstatus = request.query_params.get("status")
        method  = request.query_params.get("method")
        if pstatus:
            qs = qs.filter(status=pstatus)
        if method:
            qs = qs.filter(payment_method=method)
        serializer = PaymentSerializer(qs, many=True)
        return Response(serializer.data)
