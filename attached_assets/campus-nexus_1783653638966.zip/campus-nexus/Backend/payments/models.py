# ============================================================
#  payments/models.py
#  Payment model supporting Stripe & PayPal
# ============================================================

from django.db import models
from users.models import User
from bookings.models import Booking


class Payment(models.Model):
    METHOD_STRIPE  = "stripe"
    METHOD_PAYPAL  = "paypal"
    METHOD_CHOICES = [
        (METHOD_STRIPE, "Stripe"),
        (METHOD_PAYPAL, "PayPal"),
    ]

    STATUS_PENDING   = "pending"
    STATUS_COMPLETED = "completed"
    STATUS_FAILED    = "failed"
    STATUS_REFUNDED  = "refunded"
    STATUS_CHOICES   = [
        (STATUS_PENDING,   "Pending"),
        (STATUS_COMPLETED, "Completed"),
        (STATUS_FAILED,    "Failed"),
        (STATUS_REFUNDED,  "Refunded"),
    ]

    TYPE_DEPOSIT    = "deposit"
    TYPE_FIRST_RENT = "first_rent"
    TYPE_MONTHLY    = "monthly"
    TYPE_CHOICES    = [
        (TYPE_DEPOSIT,    "Security Deposit"),
        (TYPE_FIRST_RENT, "First Month Rent"),
        (TYPE_MONTHLY,    "Monthly Rent"),
    ]

    booking              = models.ForeignKey(
        Booking, on_delete=models.CASCADE, related_name="payments"
    )
    payer                = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="payments"
    )
    amount               = models.DecimalField(max_digits=12, decimal_places=2)
    currency             = models.CharField(max_length=3, default="LKR")
    payment_method       = models.CharField(max_length=10, choices=METHOD_CHOICES)
    payment_type         = models.CharField(max_length=15, choices=TYPE_CHOICES, default=TYPE_DEPOSIT)
    status               = models.CharField(max_length=15, choices=STATUS_CHOICES, default=STATUS_PENDING)

    # Stripe fields
    stripe_payment_intent_id = models.CharField(max_length=200, blank=True, null=True)
    stripe_client_secret     = models.CharField(max_length=500, blank=True, null=True)

    # PayPal fields
    paypal_order_id      = models.CharField(max_length=200, blank=True, null=True)
    paypal_capture_id    = models.CharField(max_length=200, blank=True, null=True)

    # Generic fields
    transaction_ref      = models.CharField(max_length=200, blank=True, null=True)
    paid_at              = models.DateTimeField(null=True, blank=True)
    created_at           = models.DateTimeField(auto_now_add=True)
    updated_at           = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "payments"
        ordering = ["-created_at"]

    def __str__(self):
        return f"Payment #{self.id} — {self.payer.email} — {self.amount} {self.currency} ({self.status})"
