# ============================================================
#  Backend/urls.py — Campus Nexus root URL configuration
# ============================================================

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import TokenRefreshView

from users.views import LoginView, LogoutView, RegisterView, AdminUserListView, AdminUserActionView
from listings.owner_views import OwnerListingView, OwnerListingEditView, ListingImageUploadView
from reviews.reviews import ReviewListView, ReviewSummaryView, ReviewCreateView
from inquiries.inquiries import InquiryCreateView, OwnerInboxView
from bookings.bookings import (
    BookingCreateView, BookingConfirmView,
    BookingReceiptView, StudentBookingListView, OwnerBookingListView,
)
from listings.views import (
    ListingSearchView,
    ListingFeaturedView,
    ListingDetailView,
    AdminListingApproveView,
    AdminListingListView,
)
from payments.views import AdminPaymentListView

urlpatterns = [
    # Django admin
    path("admin/", admin.site.urls),

    # AUTH
    path("api/auth/register/",      RegisterView.as_view(),     name="register"),
    path("api/auth/login/",         LoginView.as_view(),        name="login"),
    path("api/auth/logout/",        LogoutView.as_view(),       name="logout"),
    path("api/auth/token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),

    # PUBLIC LISTINGS
    path("api/listings/search/",   ListingSearchView.as_view(),   name="listing_search"),
    path("api/listings/featured/", ListingFeaturedView.as_view(), name="listing_featured"),
    path("api/listings/<int:pk>/", ListingDetailView.as_view(),   name="listing_detail"),

    # LISTINGS CRUD + IMAGES (owner)
    path("api/listings/", include("listings.urls")),

    # OWNER: listings management
    path("api/owner/listings/",                 OwnerListingView.as_view(),       name="owner_listings"),
    path("api/owner/listings/<int:pk>/",        OwnerListingEditView.as_view(),   name="owner_listing_edit"),
    path("api/owner/listings/<int:pk>/images/", ListingImageUploadView.as_view(), name="listing_image_upload"),

    # REVIEWS
    path("api/reviews/",         ReviewListView.as_view(),    name="review_list"),
    path("api/reviews/summary/", ReviewSummaryView.as_view(), name="review_summary"),
    path("api/reviews/create/",  ReviewCreateView.as_view(),  name="review_create"),

    # INQUIRIES
    path("api/inquiries/",            InquiryCreateView.as_view(), name="inquiry_create"),
    path("api/owner/inbox/",          OwnerInboxView.as_view(),    name="owner_inbox"),
    path("api/owner/inbox/<int:pk>/", OwnerInboxView.as_view(),    name="owner_inbox_detail"),

    # BOOKINGS
    path("api/bookings/",                  StudentBookingListView.as_view(), name="student_bookings"),
    path("api/bookings/create/",           BookingCreateView.as_view(),      name="booking_create"),
    path("api/bookings/<int:pk>/receipt/", BookingReceiptView.as_view(),     name="booking_receipt"),
    path("api/owner/bookings/",            OwnerBookingListView.as_view(),   name="owner_bookings"),
    path("api/owner/bookings/<int:pk>/",   BookingConfirmView.as_view(),     name="booking_confirm"),

    # PAYMENTS (Stripe + PayPal)
    path("api/payments/", include("payments.urls")),

    # MESSAGING (bidirectional student <-> owner)
    path("api/messages/", include("messaging.urls")),

    # ADMIN
    path("api/admin/listings/",          AdminListingListView.as_view(),    name="admin_listing_list"),
    path("api/admin/listings/<int:pk>/", AdminListingApproveView.as_view(), name="admin_listing_approve"),
    path("api/admin/users/",             AdminUserListView.as_view(),        name="admin_user_list"),
    path("api/admin/users/<int:pk>/",    AdminUserActionView.as_view(),      name="admin_user_detail"),
    path("api/admin/payments/",          AdminPaymentListView.as_view(),     name="admin_payment_list"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
