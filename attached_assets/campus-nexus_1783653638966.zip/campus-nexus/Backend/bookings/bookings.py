# ============================================================
#  GIMSARA — bookings/bookings.py
#  Booking API — create, confirm, receipt generation
# ============================================================

from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from rest_framework.permissions import IsAuthenticated

from bookings.models import Booking
from listings.models import Listing, ListingImage


# ── SERIALIZERS ───────────────────────────────────────────────

class BookingCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Booking
        fields = ["listing", "move_in_date", "message"]

    def validate_move_in_date(self, value):
        if value < timezone.now().date():
            raise serializers.ValidationError("Move-in date cannot be in the past.")
        return value


class BookingReadSerializer(serializers.ModelSerializer):
    listing_name  = serializers.SerializerMethodField()
    listing_area  = serializers.SerializerMethodField()
    listing_price = serializers.SerializerMethodField()
    student_name  = serializers.SerializerMethodField()

    class Meta:
        model  = Booking
        fields = [
            "id", "listing_name", "listing_area", "listing_price",
            "student_name", "status", "move_in_date", "message",
            "confirmed_at", "created_at",
        ]

    def get_listing_name(self, obj):  return obj.listing.name
    def get_listing_area(self, obj):  return obj.listing.area
    def get_listing_price(self, obj): return obj.listing.price
    def get_student_name(self, obj):  return obj.student.get_full_name()


# ── VIEWS ─────────────────────────────────────────────────────

class BookingCreateView(APIView):
    """
    POST /api/bookings/create/
    Student creates a booking request.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if request.user.role != "student":
            return Response(
                {"detail": "Only students can make bookings."},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = BookingCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        listing = serializer.validated_data["listing"]

        if Booking.objects.filter(
            listing=listing, student=request.user,
            status=Booking.STATUS_PENDING
        ).exists():
            return Response(
                {"detail": "You already have a pending booking for this listing."},
                status=status.HTTP_400_BAD_REQUEST
            )

        booking = serializer.save(student=request.user)
        return Response(
            {"detail": "Booking request sent.", "id": booking.id},
            status=status.HTTP_201_CREATED
        )


class BookingConfirmView(APIView):
    """
    PATCH /api/owner/bookings/<pk>/
    Owner confirms or cancels a booking.
    """
    permission_classes = [IsAuthenticated]

    def patch(self, request, pk):
        if request.user.role not in ("owner", "admin"):
            return Response(
                {"detail": "Owner access required."},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            booking = Booking.objects.get(pk=pk, listing__owner=request.user)
        except Booking.DoesNotExist:
            return Response({"detail": "Booking not found."}, status=status.HTTP_404_NOT_FOUND)

        new_status = request.data.get("status")
        if new_status not in [Booking.STATUS_CONFIRMED, Booking.STATUS_CANCELLED]:
            return Response(
                {"status": "Must be 'confirmed' or 'cancelled'."},
                status=status.HTTP_400_BAD_REQUEST
            )

        booking.status = new_status
        if new_status == Booking.STATUS_CONFIRMED:
            booking.confirmed_at = timezone.now()
        booking.save(update_fields=["status", "confirmed_at"])

        return Response({"detail": f"Booking {new_status}.", "id": booking.id})


class BookingReceiptView(APIView):
    """
    GET /api/bookings/<pk>/receipt/
    Generate a receipt for a confirmed booking.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            booking = Booking.objects.select_related(
                "listing", "student", "listing__owner"
            ).get(pk=pk)
        except Booking.DoesNotExist:
            return Response({"detail": "Booking not found."}, status=status.HTTP_404_NOT_FOUND)

        if request.user != booking.student and request.user != booking.listing.owner:
            return Response({"detail": "Not allowed."}, status=status.HTTP_403_FORBIDDEN)

        if booking.status != Booking.STATUS_CONFIRMED:
            return Response(
                {"detail": "Receipt only available for confirmed bookings."},
                status=status.HTTP_400_BAD_REQUEST
            )

        receipt = {
            "receipt_id":    f"RCP-{booking.id:05d}",
            "booking_id":    booking.id,
            "student_name":  booking.student.get_full_name(),
            "student_email": booking.student.email,
            "listing_name":  booking.listing.name,
            "listing_area":  booking.listing.area,
            "listing_type":  booking.listing.type,
            "owner_name":    booking.listing.owner.get_full_name(),
            "owner_email":   booking.listing.owner.email,
            "monthly_rent":  booking.listing.price,
            "deposit":       booking.listing.price * booking.listing.deposit_months,
            "move_in_date":  booking.move_in_date,
            "confirmed_at":  booking.confirmed_at,
            "status":        booking.status,
            "issued_at":     timezone.now(),
        }
        return Response(receipt)


class StudentBookingListView(APIView):
    """
    GET /api/bookings/
    Student sees their own bookings.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if request.user.role != "student":
            return Response({"detail": "Student access required."}, status=status.HTTP_403_FORBIDDEN)

        bookings = Booking.objects.filter(
            student=request.user
        ).select_related("listing")
        serializer = BookingReadSerializer(bookings, many=True)
        return Response(serializer.data)


class OwnerBookingListView(APIView):
    """
    GET /api/owner/bookings/
    Owner sees all bookings for their listings.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if request.user.role not in ("owner", "admin"):
            return Response({"detail": "Owner access required."}, status=status.HTTP_403_FORBIDDEN)

        bookings = Booking.objects.filter(
            listing__owner=request.user
        ).select_related("student", "listing")
        serializer = BookingReadSerializer(bookings, many=True)
        return Response(serializer.data)