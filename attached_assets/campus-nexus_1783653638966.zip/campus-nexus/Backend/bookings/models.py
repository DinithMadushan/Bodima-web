# ============================================================
#  GIMSARA — bookings/models.py
#  Booking model — create, confirm, receipt
# ============================================================

from django.db import models
from users.models import User
from listings.models import Listing


class Booking(models.Model):
    STATUS_PENDING   = "pending"
    STATUS_CONFIRMED = "confirmed"
    STATUS_CANCELLED = "cancelled"
    STATUS_CHOICES   = [
        (STATUS_PENDING,   "Pending"),
        (STATUS_CONFIRMED, "Confirmed"),
        (STATUS_CANCELLED, "Cancelled"),
    ]

    listing      = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="bookings")
    student      = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bookings")
    status       = models.CharField(max_length=15, choices=STATUS_CHOICES, default=STATUS_PENDING)
    move_in_date = models.DateField()
    message      = models.TextField(blank=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)   # ← NEW: set when confirmed
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "bookings"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student.get_full_name()} → {self.listing.name} ({self.status})"